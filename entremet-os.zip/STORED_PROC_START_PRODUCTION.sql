-- ============================================================================
-- STORED PROCEDURE: sp_start_production_atomic
-- ============================================================================
-- Descrição: Inicia produção de forma atômica (validação + dedução + status)
-- Banco: TiDB/MySQL (compatível com transações ACID)
-- 
-- Estratégia: Ultra-simplificada para máxima compatibilidade TiDB
-- Toda lógica crítica no banco com transação atômica.
-- 
-- Parâmetros:
--   p_ordem_id: UUID da ordem de produção
--   p_produto_id: UUID do produto a produzir
--   p_quantidade: Quantidade a produzir (DECIMAL)
--
-- Retorno (via SELECT):
--   {
--     success: BOOLEAN,
--     message: VARCHAR,
--     ordem_id: UUID (se sucesso),
--     deficits: JSON array ([] se sem déficits),
--     error_code: VARCHAR
--   }
-- ============================================================================

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_start_production_atomic$$

CREATE PROCEDURE sp_start_production_atomic(
  IN p_ordem_id CHAR(36),
  IN p_produto_id CHAR(36),
  IN p_quantidade DECIMAL(10, 2)
)
BEGIN
  -- Handler para erros SQL - rollback automático
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    SELECT 
      FALSE as success,
      'Erro ao iniciar produção' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'SQL_ERROR' as error_code;
  END;

  -- ========================================================================
  -- PASSO 1: Validar se ordem existe e está em status permitido
  -- ========================================================================
  IF NOT EXISTS (SELECT 1 FROM ordens_producao WHERE id = p_ordem_id AND status = 'pendente') THEN
    SELECT 
      FALSE as success,
      'Ordem não encontrada ou status inválido' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'INVALID_ORDER' as error_code;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 2 + 3: Validar estoque consolidado (fichas + insumos separados)
  -- ========================================================================
  
  -- Se houver déficits, retornar erro com lista
  IF EXISTS (
    SELECT 1
    FROM (
      SELECT 
        consolidated.insumo_id,
        consolidated.insumo_nome,
        consolidated.quantidade_total * p_quantidade as quantidade_necessaria,
        COALESCE(SUM(l.quantidade_atual), 0) as quantidade_disponivel
      FROM (
        SELECT 
          i.id as insumo_id,
          i.nome as insumo_nome,
          SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total
        FROM produto_fichas_tecnicas pft
        JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
        JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
        JOIN `Insumos` i ON ing.insumo_id = i.id
        WHERE pft.produto_id = p_produto_id
        GROUP BY i.id, i.nome
        
        UNION ALL
        
        SELECT 
          i.id as insumo_id,
          i.nome as insumo_nome,
          pi.quantidade as quantidade_total
        FROM produto_insumo pi
        JOIN `Insumos` i ON pi.insumo_id = i.id
        WHERE pi.produto_id = p_produto_id
      ) consolidated
      LEFT JOIN lotes l ON consolidated.insumo_id = l.insumo_id
      GROUP BY consolidated.insumo_id, consolidated.insumo_nome, consolidated.quantidade_total
      HAVING COALESCE(SUM(l.quantidade_atual), 0) < consolidated.quantidade_total * p_quantidade
    ) deficits
  ) THEN
    SELECT 
      FALSE as success,
      'Estoque insuficiente para os seguintes insumos' as message,
      NULL as ordem_id,
      COALESCE(
        JSON_ARRAYAGG(
          JSON_OBJECT(
            'insumo_id', insumo_id,
            'insumo_nome', insumo_nome,
            'necessario', quantidade_necessaria,
            'disponivel', quantidade_disponivel,
            'deficit', quantidade_necessaria - quantidade_disponivel
          )
        ),
        JSON_ARRAY()
      ) as deficits,
      'INSUFFICIENT_STOCK' as error_code
    FROM (
      SELECT 
        consolidated.insumo_id,
        consolidated.insumo_nome,
        consolidated.quantidade_total * p_quantidade as quantidade_necessaria,
        COALESCE(SUM(l.quantidade_atual), 0) as quantidade_disponivel
      FROM (
        SELECT 
          i.id as insumo_id,
          i.nome as insumo_nome,
          SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total
        FROM produto_fichas_tecnicas pft
        JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
        JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
        JOIN `Insumos` i ON ing.insumo_id = i.id
        WHERE pft.produto_id = p_produto_id
        GROUP BY i.id, i.nome
        
        UNION ALL
        
        SELECT 
          i.id as insumo_id,
          i.nome as insumo_nome,
          pi.quantidade as quantidade_total
        FROM produto_insumo pi
        JOIN `Insumos` i ON pi.insumo_id = i.id
        WHERE pi.produto_id = p_produto_id
      ) consolidated
      LEFT JOIN lotes l ON consolidated.insumo_id = l.insumo_id
      GROUP BY consolidated.insumo_id, consolidated.insumo_nome, consolidated.quantidade_total
      HAVING COALESCE(SUM(l.quantidade_atual), 0) < consolidated.quantidade_total * p_quantidade
    ) deficits;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 4: Deduzir estoque (FIFO por created_at)
  -- ========================================================================
  
  -- Registrar consumo de estoque em FIFO
  INSERT INTO baixa_estoque (
    id,
    lote_id,
    quantidade_baixada,
    motivo,
    data_baixa,
    referencia_producao_id,
    tipo_movimentacao,
    created_at,
    updated_at
  )
  SELECT 
    UUID() as id,
    l.id as lote_id,
    GREATEST(
      0,
      LEAST(
        l.quantidade_atual,
        consolidated_qty.quantidade_necessaria - COALESCE(
          (SELECT COALESCE(SUM(l2.quantidade_atual), 0) 
           FROM lotes l2 
           WHERE l2.insumo_id = l.insumo_id 
           AND l2.created_at > l.created_at),
          0
        )
      )
    ) as quantidade_baixada,
    'producao' as motivo,
    NOW() as data_baixa,
    p_ordem_id as referencia_producao_id,
    'consumo_producao' as tipo_movimentacao,
    NOW() as created_at,
    NOW() as updated_at
  FROM (
    SELECT 
      consolidated.insumo_id,
      consolidated.quantidade_total * p_quantidade as quantidade_necessaria
    FROM (
      SELECT 
        i.id as insumo_id,
        SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total
      FROM produto_fichas_tecnicas pft
      JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
      JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
      JOIN `Insumos` i ON ing.insumo_id = i.id
      WHERE pft.produto_id = p_produto_id
      GROUP BY i.id
      
      UNION ALL
      
      SELECT 
        i.id as insumo_id,
        pi.quantidade as quantidade_total
      FROM produto_insumo pi
      JOIN `Insumos` i ON pi.insumo_id = i.id
      WHERE pi.produto_id = p_produto_id
    ) consolidated
    GROUP BY consolidated.insumo_id
  ) consolidated_qty
  JOIN lotes l ON consolidated_qty.insumo_id = l.insumo_id;
  
  -- Atualizar quantidade dos lotes (deduzir o que foi consumido)
  UPDATE lotes l
  JOIN baixa_estoque be ON l.id = be.lote_id
  SET l.quantidade_atual = l.quantidade_atual - be.quantidade_baixada
  WHERE be.referencia_producao_id = p_ordem_id;

  -- ========================================================================
  -- PASSO 5: Atualizar status da ordem para 'em_andamento'
  -- ========================================================================
  UPDATE ordens_producao
  SET 
    status = 'em_andamento',
    data_inicio = NOW(),
    updated_at = NOW()
  WHERE id = p_ordem_id;

  -- ========================================================================
  -- PASSO 6: Retornar resultado de sucesso
  -- ========================================================================
  SELECT 
    TRUE as success,
    'Produção iniciada com sucesso' as message,
    p_ordem_id as ordem_id,
    JSON_ARRAY() as deficits,
    'SUCCESS' as error_code;

END$$

DELIMITER ;

