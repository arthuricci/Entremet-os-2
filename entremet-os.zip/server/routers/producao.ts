/**
 * Production Router - tRPC Procedures
 * 
 * Handles atomic production start with complete orchestration:
 * 1. Validate order
 * 2. Consolidate ingredients
 * 3. Validate stock
 * 4. Calculate deficits
 * 5. Deduct stock (FIFO)
 * 6. Register consumption
 * 7. Update lotes
 * 8. Update order status
 * 
 * All steps execute within a single transaction.
 * Any error causes automatic rollback.
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  validateProductionOrder,
  consolidateIngredients,
  validateStock,
  calculateDeficits,
  deductStockFIFO,
  updateLotesQuantities,
  updateOrderStatus,
  StockDeficit,
} from "../db-production";
import { getDb } from "../db";
import { sql } from "drizzle-orm";

/**
 * Response type for production start
 */
export interface StartProductionResponse {
  success: boolean;
  message: string;
  ordemId?: string;
  deficits?: StockDeficit[];
  errorCode?: string;
}

/**
 * Production Router
 */
export const producaoRouter = router({
  /**
   * Start Production (Atomic)
   * 
   * Orchestrates all 8 steps within a single transaction.
   * 
   * Input:
   * - ordemId: UUID of the production order
   * - produtoId: UUID of the product
   * - quantidade: Quantity to produce
   * 
   * Output:
   * - success: boolean
   * - message: string
   * - ordemId: UUID (if success)
   * - deficits: Array of StockDeficit (if stock validation fails)
   * - errorCode: string (if error)
   */
  startProduction: protectedProcedure
    .input(
      z.object({
        ordemId: z.string().uuid("Invalid order ID"),
        produtoId: z.string().uuid("Invalid product ID"),
        quantidade: z.number().positive("Quantity must be positive"),
      })
    )
    .mutation(async ({ input }): Promise<StartProductionResponse> => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Database connection not available",
        });
      }

      try {
        // ===================================
        // BEGIN TRANSACTION
        // ===================================
        await db!.execute(sql`START TRANSACTION`);

        try {
          // ===================================
          // ETAPA 1: Validar Ordem
          // ===================================
          console.log(`[ETAPA 1] Validando ordem: ${input.ordemId}`);
          const isValidOrder = await validateProductionOrder(input.ordemId);
          console.log(`[ETAPA 1] Resultado: ${isValidOrder ? 'VÁLIDA' : 'INVÁLIDA'}`);
          if (!isValidOrder) {
            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Ordem não encontrada ou status inválido",
              errorCode: "INVALID_ORDER",
            };
          }

          // ===================================
          // ETAPA 2: Consolidar Insumos
          // ===================================
          console.log(`[ETAPA 2] Consolidando insumos do produto: ${input.produtoId}`);
          const consolidatedIngredients = await consolidateIngredients(
            input.produtoId
          );
          console.log(`[ETAPA 2] Insumos consolidados: ${consolidatedIngredients.length}`, consolidatedIngredients);

          if (consolidatedIngredients.length === 0) {
            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Produto não possui insumos associados",
              errorCode: "NO_INGREDIENTS",
            };
          }

          // ===================================
          // ETAPA 3: Validar Estoque
          // ===================================
          console.log(`[ETAPA 3] Validando estoque para quantidade: ${input.quantidade}`);
          const hasStock = await validateStock(
            consolidatedIngredients,
            input.quantidade
          );
          console.log(`[ETAPA 3] Resultado: ${hasStock ? 'SUFICIENTE' : 'INSUFICIENTE'}`);

          if (!hasStock) {
            // ===================================
            // ETAPA 4: Calcular Déficits
            // ===================================
            console.log(`[ETAPA 4] Calculando déficits`);
            const deficits = await calculateDeficits(
              consolidatedIngredients,
              input.quantidade
            );
            console.log(`[ETAPA 4] Déficits encontrados: ${deficits.length}`, deficits);

            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Estoque insuficiente para produção",
              deficits,
              errorCode: "INSUFFICIENT_STOCK",
            };
          }

          // ===================================
          // ETAPA 5 + 6: Deduzir Estoque (FIFO) + Registrar Consumo
          // ===================================
          console.log(`[ETAPA 5-6] Iniciando dedução FIFO para ordem: ${input.ordemId}`);
          const deductionSuccess = await deductStockFIFO(
            input.ordemId,
            consolidatedIngredients,
            input.quantidade
          );
          console.log(`[ETAPA 5-6] Dedução FIFO: ${deductionSuccess ? 'SUCESSO' : 'FALHA'}`);

          if (!deductionSuccess) {
            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Erro ao deduzir estoque",
              errorCode: "DEDUCTION_FAILED",
            };
          }

          // ===================================
          // ETAPA 7: Atualizar Lotes
          // ===================================
          console.log(`[ETAPA 7] Atualizando quantidades dos lotes`);
          const updateSuccess = await updateLotesQuantities(input.ordemId);
          console.log(`[ETAPA 7] Atualização de lotes: ${updateSuccess ? 'SUCESSO' : 'FALHA'}`);

          if (!updateSuccess) {
            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Erro ao atualizar lotes",
              errorCode: "UPDATE_LOTES_FAILED",
            };
          }

          // ===================================
          // ETAPA 8: Atualizar Status da Ordem
          // ===================================
          console.log(`[ETAPA 8] Atualizando status da ordem para 'em_andamento'`);
          const statusSuccess = await updateOrderStatus(input.ordemId);
          console.log(`[ETAPA 8] Atualização de status: ${statusSuccess ? 'SUCESSO' : 'FALHA'}`);

          if (!statusSuccess) {
            await db!.execute(sql`ROLLBACK`);
            return {
              success: false,
              message: "Erro ao atualizar status da ordem",
              errorCode: "UPDATE_STATUS_FAILED",
            };
          }

          // ===================================
          // COMMIT TRANSACTION
          // ===================================
          console.log(`[COMMIT] Commitando transação para ordem: ${input.ordemId}`);
          await db!.execute(sql`COMMIT`);
          console.log(`[COMMIT] Transação commitada com sucesso`);

          return {
            success: true,
            message: "Produção iniciada com sucesso",
            ordemId: input.ordemId,
          };
          } catch (innerError) {
          // Inner try-catch: Rollback on any error
          await db!.execute(sql`ROLLBACK`);
          throw innerError;
        }
      } catch (error) {
        console.error("[tRPC] Error in startProduction:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao iniciar produção",
          cause: error,
        });
      }
    }),
});
