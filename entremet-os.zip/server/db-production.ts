/**
 * Production Start Logic - Database Helpers
 * 
 * Implements atomic production start with:
 * - Order validation
 * - Ingredient consolidation (recipes + separate)
 * - Stock validation
 * - FIFO deduction
 * - Stock tracking
 * - Order status update
 */

import { eq, and, sql, gte, lte, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { getDb } from "./db";
import { ENV } from "./_core/env";

/**
 * ETAPA 1: Validar Ordem
 * 
 * Verifica se:
 * - Ordem existe
 * - Status é 'pendente'
 * 
 * @param ordemId UUID da ordem
 * @returns true se válida, false caso contrário
 */
export async function validateProductionOrder(ordemId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    const result = await db.execute(sql`
      SELECT COUNT(*) as count
      FROM ordens_producao
      WHERE id = ${ordemId} AND status = 'pendente'
    `);

    const rows = result as any[];
    return rows.length > 0 && rows[0].count > 0;
  } catch (error) {
    console.error("[DB] Error validating production order:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 2: Consolidar Insumos
 * 
 * Consolida insumos de:
 * - Fichas técnicas associadas ao produto
 * - Insumos separados do produto
 * 
 * Retorna lista de insumos com quantidade total necessária
 * 
 * @param produtoId UUID do produto
 * @returns Array de { insumoId, insumoNome, quantidadeTotal }
 */
export interface ConsolidatedIngredient {
  insumoId: string;
  insumoNome: string;
  quantidadeTotal: number;
}

export async function consolidateIngredients(
  produtoId: string
): Promise<ConsolidatedIngredient[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    // Query: UNION ALL de fichas técnicas + insumos separados
    const result = await db.execute(sql`
      -- Fichas Técnicas
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total
      FROM produto_fichas_tecnicas pft
      JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
      JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
      JOIN \`Insumos\` i ON ing.insumo_id = i.id
      WHERE pft.produto_id = ${produtoId}
      GROUP BY i.id, i.nome
      
      UNION ALL
      
      -- Insumos Separados
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        pi.quantidade as quantidade_total
      FROM produto_insumo pi
      JOIN \`Insumos\` i ON pi.insumo_id = i.id
      WHERE pi.produto_id = ${produtoId}
    `);

    const rows = result as any[];
    // [] é permitido quando a query executa corretamente mas não encontra insumos
    return rows.map((row) => ({
      insumoId: row.insumo_id,
      insumoNome: row.insumo_nome,
      quantidadeTotal: parseFloat(row.quantidade_total),
    }));
  } catch (error) {
    console.error("[DB] Error consolidating ingredients:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 3: Validar Estoque
 * 
 * Verifica se há estoque suficiente para todos os insumos
 * Retorna true se há estoque, false se há déficit
 * 
 * @param consolidatedIngredients Insumos consolidados
 * @param quantidade Quantidade a produzir
 * @returns true se há estoque suficiente, false caso contrário
 */
export async function validateStock(
  consolidatedIngredients: ConsolidatedIngredient[],
  quantidade: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    for (const ingredient of consolidatedIngredients) {
      const necessario = ingredient.quantidadeTotal * quantidade;

      const result = await db.execute(sql`
        SELECT COALESCE(SUM(quantidade_atual), 0) as disponivel
        FROM lotes
        WHERE insumo_id = ${ingredient.insumoId}
      `);

      const rows = result as any[];
      const disponivel = rows.length > 0 ? parseFloat(rows[0].disponivel) : 0;

      if (disponivel < necessario) {
        return false; // Há déficit
      }
    }

    return true; // Estoque suficiente
  } catch (error) {
    console.error("[DB] Error validating stock:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 4: Calcular Déficits
 * 
 * Calcula déficits de estoque para cada insumo
 * Retorna array vazio se não há déficits
 * Retorna array com déficits se há falta de estoque
 * 
 * @param consolidatedIngredients Insumos consolidados
 * @param quantidade Quantidade a produzir
 * @returns Array de { insumoId, insumoNome, necessario, disponivel, deficit }
 */
export interface StockDeficit {
  insumoId: string;
  insumoNome: string;
  necessario: number;
  disponivel: number;
  deficit: number;
}

export async function calculateDeficits(
  consolidatedIngredients: ConsolidatedIngredient[],
  quantidade: number
): Promise<StockDeficit[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    const deficits: StockDeficit[] = [];

    for (const ingredient of consolidatedIngredients) {
      const necessario = ingredient.quantidadeTotal * quantidade;

      const result = await db.execute(sql`
        SELECT COALESCE(SUM(quantidade_atual), 0) as disponivel
        FROM lotes
        WHERE insumo_id = ${ingredient.insumoId}
      `);

      const rows = result as any[];
      const disponivel = rows.length > 0 ? parseFloat(rows[0].disponivel) : 0;

      if (disponivel < necessario) {
        deficits.push({
          insumoId: ingredient.insumoId,
          insumoNome: ingredient.insumoNome,
          necessario,
          disponivel,
          deficit: necessario - disponivel,
        });
      }
    }

    // [] é permitido quando não há déficits
    return deficits;
  } catch (error) {
    console.error("[DB] Error calculating deficits:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 5: Deduzir Estoque (FIFO)
 * 
 * Deduz estoque em FIFO (lotes mais antigos primeiro)
 * Registra cada movimento em baixa_estoque
 * 
 * @param ordemId UUID da ordem
 * @param consolidatedIngredients Insumos consolidados
 * @param quantidade Quantidade a produzir
 * @returns true se bem-sucedido, false caso contrário
 */
export async function deductStockFIFO(
  ordemId: string,
  consolidatedIngredients: ConsolidatedIngredient[],
  quantidade: number
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    for (const ingredient of consolidatedIngredients) {
      const necessario = ingredient.quantidadeTotal * quantidade;
      let restante = necessario;

      // Query: Lotes em FIFO (created_at ASC)
      const lotesResult = await db.execute(sql`
        SELECT id, quantidade_atual
        FROM lotes
        WHERE insumo_id = ${ingredient.insumoId}
        ORDER BY created_at ASC
      `);

      const lotes = lotesResult as any[];

      for (const lote of lotes) {
        if (restante <= 0) break;

        const loteId = lote.id;
        const loteQuantidade = parseFloat(lote.quantidade_atual);
        const deduzir = Math.min(loteQuantidade, restante);

        // Registrar consumo em baixa_estoque
        await db.execute(sql`
          INSERT INTO baixa_estoque (
            id,
            lote_id,
            quantidade_baixada,
            motivo,
            data_baixa,
            referencia_producao_id,
            tipo_movimentacao,
            created_at,
            updated_at
          ) VALUES (
            UUID(),
            ${loteId},
            ${deduzir},
            'producao',
            NOW(),
            ${ordemId},
            'consumo_producao',
            NOW(),
            NOW()
          )
        `);

        restante -= deduzir;
      }
    }

    return true;
  } catch (error) {
    console.error("[DB] Error deducting stock FIFO:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 6 + 7: Atualizar Lotes
 * 
 * Deduz quantidade dos lotes baseado nos movimentos registrados
 * 
 * @param ordemId UUID da ordem
 * @returns true se bem-sucedido, false caso contrário
 */
export async function updateLotesQuantities(ordemId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    // Query: Agrupar movimentos por lote e deduzir
    await db.execute(sql`
      UPDATE lotes l
      JOIN (
        SELECT 
          lote_id,
          SUM(quantidade_baixada) as total_baixado
        FROM baixa_estoque
        WHERE referencia_producao_id = ${ordemId}
        GROUP BY lote_id
      ) be ON l.id = be.lote_id
      SET l.quantidade_atual = l.quantidade_atual - be.total_baixado
    `);

    return true;
  } catch (error) {
    console.error("[DB] Error updating lote quantities:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * ETAPA 8: Atualizar Status da Ordem
 * 
 * Atualiza status para 'em_andamento' e registra data_inicio
 * 
 * @param ordemId UUID da ordem
 * @returns true se bem-sucedido, false caso contrário
 */
export async function updateOrderStatus(ordemId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    const result = await db.execute(sql`
      UPDATE ordens_producao
      SET 
        status = 'em_andamento',
        data_inicio = NOW(),
        updated_at = NOW()
      WHERE id = ${ordemId}
    `);

    return true;
  } catch (error) {
    console.error("[DB] Error updating order status:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

/**
 * Rollback: Limpar movimentos de consumo
 * 
 * Remove todos os movimentos de consumo registrados para uma ordem
 * Usado em caso de erro durante a transação
 * 
 * @param ordemId UUID da ordem
 * @returns true se bem-sucedido, false caso contrário
 */
export async function rollbackProductionMovements(
  ordemId: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    throw new Error("[DB] Database connection not available");
  }

  try {
    await db.execute(sql`
      DELETE FROM baixa_estoque
      WHERE referencia_producao_id = ${ordemId}
      AND tipo_movimentacao = 'consumo_producao'
    `);

    return true;
  } catch (error) {
    console.error("[DB] Error rolling back production movements:", error);
    throw error; // Lançar exceção para abortar transação
  }
}

