-- ============================================================================
-- RPC: start_production_atomic
-- ============================================================================
-- Descrição: Inicia produção de forma atômica (validação + dedução + status)
-- Transação: Toda a operação é atômica. Falha em qualquer ponto = ROLLBACK
-- 
-- Parâmetros:
--   p_ordem_id: UUID da ordem de produção
--   p_produto_id: UUID do produto a produzir
--   p_quantidade: Quantidade a produzir (number)
--
-- Retorno:
--   {
--     success: boolean,
--     message: string,
--     ordem_id: UUID (se sucesso),
--     deficits: array de objetos (se falha na validação)
--   }
-- ============================================================================

CREATE OR REPLACE FUNCTION start_production_atomic(
  p_ordem_id UUID,
  p_produto_id UUID,
  p_quantidade NUMERIC
)
RETURNS JSON AS $$
DECLARE
  v_ordem_status VARCHAR;
  v_insumo_record RECORD;
  v_quantidade_necessaria NUMERIC;
  v_quantidade_disponivel NUMERIC;
  v_deficits JSONB := '[]'::JSONB;
  v_lote_record RECORD;
  v_quantidade_a_deduzir NUMERIC;
  v_nova_quantidade_lote NUMERIC;
BEGIN
  -- ========================================================================
  -- PASSO 1: Validar se ordem existe e está em status permitido
  -- ========================================================================
  SELECT status INTO v_ordem_status
  FROM ordens_producao
  WHERE id = p_ordem_id;

  IF v_ordem_status IS NULL THEN
    RETURN JSON_BUILD_OBJECT(
      'success', FALSE,
      'message', 'Ordem de produção não encontrada'
    );
  END IF;

  IF v_ordem_status != 'pendente' THEN
    RETURN JSON_BUILD_OBJECT(
      'success', FALSE,
      'message', 'Produção já foi iniciada ou finalizada. Status atual: ' || v_ordem_status
    );
  END IF;

  -- ========================================================================
  -- PASSO 2 + 3: Consolidar insumos (fichas + separados) + Validar estoque
  -- ========================================================================
  -- Usar CTE para consolidar insumos de fichas técnicas e insumos separados
  WITH insumos_fichas AS (
    -- Insumos das fichas técnicas vinculadas ao produto
    SELECT 
      i.id as insumo_id,
      i.nome as insumo_nome,
      SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total,
      i.unidade_base
    FROM produto_fichas_tecnicas pft
    JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
    JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
    JOIN "Insumos" i ON ing.insumo_id = i.id
    WHERE pft.produto_id = p_produto_id
    GROUP BY i.id, i.nome, i.unidade_base
  ),
  insumos_separados AS (
    -- Insumos adicionados separadamente ao produto
    SELECT 
      i.id as insumo_id,
      i.nome as insumo_nome,
      pi.quantidade as quantidade_total,
      i.unidade_base
    FROM produto_insumo pi
    JOIN "Insumos" i ON pi.insumo_id = i.id
    WHERE pi.produto_id = p_produto_id
  ),
  insumos_consolidados AS (
    -- Unificar fichas + separados, somando duplicatas
    SELECT 
      insumo_id,
      insumo_nome,
      SUM(quantidade_total) as quantidade_total,
      unidade_base
    FROM (
      SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_fichas
      UNION ALL
      SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_separados
    ) combined
    GROUP BY insumo_id, insumo_nome, unidade_base
  ),
  insumos_com_estoque AS (
    -- Calcular estoque disponível para cada insumo
    SELECT 
      ic.insumo_id,
      ic.insumo_nome,
      ic.quantidade_total,
      ic.unidade_base,
      COALESCE(SUM(l.quantidade_atual), 0) as quantidade_disponivel,
      ic.quantidade_total * p_quantidade as quantidade_necessaria
    FROM insumos_consolidados ic
    LEFT JOIN lotes l ON ic.insumo_id = l.insumo_id
    GROUP BY ic.insumo_id, ic.insumo_nome, ic.quantidade_total, ic.unidade_base
  )
  SELECT 
    insumo_id,
    insumo_nome,
    quantidade_necessaria,
    quantidade_disponivel
  INTO v_insumo_record
  FROM insumos_com_estoque
  WHERE quantidade_disponivel < quantidade_necessaria
  LIMIT 1;

  -- Se houver déficit, construir array completo de déficits
  IF v_insumo_record.insumo_id IS NOT NULL THEN
    WITH insumos_fichas AS (
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total,
        i.unidade_base
      FROM produto_fichas_tecnicas pft
      JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
      JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
      JOIN "Insumos" i ON ing.insumo_id = i.id
      WHERE pft.produto_id = p_produto_id
      GROUP BY i.id, i.nome, i.unidade_base
    ),
    insumos_separados AS (
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        pi.quantidade as quantidade_total,
        i.unidade_base
      FROM produto_insumo pi
      JOIN "Insumos" i ON pi.insumo_id = i.id
      WHERE pi.produto_id = p_produto_id
    ),
    insumos_consolidados AS (
      SELECT 
        insumo_id,
        insumo_nome,
        SUM(quantidade_total) as quantidade_total,
        unidade_base
      FROM (
        SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_fichas
        UNION ALL
        SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_separados
      ) combined
      GROUP BY insumo_id, insumo_nome, unidade_base
    ),
    insumos_com_estoque AS (
      SELECT 
        ic.insumo_id,
        ic.insumo_nome,
        ic.quantidade_total,
        ic.unidade_base,
        COALESCE(SUM(l.quantidade_atual), 0) as quantidade_disponivel,
        ic.quantidade_total * p_quantidade as quantidade_necessaria
      FROM insumos_consolidados ic
      LEFT JOIN lotes l ON ic.insumo_id = l.insumo_id
      GROUP BY ic.insumo_id, ic.insumo_nome, ic.quantidade_total, ic.unidade_base
    )
    SELECT 
      JSONB_AGG(
        JSON_BUILD_OBJECT(
          'insumo_id', insumo_id,
          'insumo_nome', insumo_nome,
          'necessario', quantidade_necessaria,
          'disponivel', quantidade_disponivel,
          'deficit', quantidade_necessaria - quantidade_disponivel
        )
      )
    INTO v_deficits
    FROM insumos_com_estoque
    WHERE quantidade_disponivel < quantidade_necessaria;

    RETURN JSON_BUILD_OBJECT(
      'success', FALSE,
      'message', 'Estoque insuficiente para os seguintes insumos',
      'deficits', v_deficits
    );
  END IF;

  -- ========================================================================
  -- PASSO 4: Deduzir estoque (FIFO por created_at)
  -- ========================================================================
  WITH insumos_fichas AS (
    SELECT 
      i.id as insumo_id,
      i.nome as insumo_nome,
      SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total,
      i.unidade_base
    FROM produto_fichas_tecnicas pft
    JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
    JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
    JOIN "Insumos" i ON ing.insumo_id = i.id
    WHERE pft.produto_id = p_produto_id
    GROUP BY i.id, i.nome, i.unidade_base
  ),
  insumos_separados AS (
    SELECT 
      i.id as insumo_id,
      i.nome as insumo_nome,
      pi.quantidade as quantidade_total,
      i.unidade_base
    FROM produto_insumo pi
    JOIN "Insumos" i ON pi.insumo_id = i.id
    WHERE pi.produto_id = p_produto_id
  ),
  insumos_consolidados AS (
    SELECT 
      insumo_id,
      insumo_nome,
      SUM(quantidade_total) as quantidade_total,
      unidade_base
    FROM (
      SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_fichas
      UNION ALL
      SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_separados
    ) combined
    GROUP BY insumo_id, insumo_nome, unidade_base
  )
  SELECT DISTINCT insumo_id, insumo_nome, quantidade_total
  INTO v_insumo_record
  FROM insumos_consolidados;

  -- Iterar sobre cada insumo consolidado
  FOR v_insumo_record IN
    WITH insumos_fichas AS (
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total,
        i.unidade_base
      FROM produto_fichas_tecnicas pft
      JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
      JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
      JOIN "Insumos" i ON ing.insumo_id = i.id
      WHERE pft.produto_id = p_produto_id
      GROUP BY i.id, i.nome, i.unidade_base
    ),
    insumos_separados AS (
      SELECT 
        i.id as insumo_id,
        i.nome as insumo_nome,
        pi.quantidade as quantidade_total,
        i.unidade_base
      FROM produto_insumo pi
      JOIN "Insumos" i ON pi.insumo_id = i.id
      WHERE pi.produto_id = p_produto_id
    ),
    insumos_consolidados AS (
      SELECT 
        insumo_id,
        insumo_nome,
        SUM(quantidade_total) as quantidade_total,
        unidade_base
      FROM (
        SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_fichas
        UNION ALL
        SELECT insumo_id, insumo_nome, quantidade_total, unidade_base FROM insumos_separados
      ) combined
      GROUP BY insumo_id, insumo_nome, unidade_base
    )
    SELECT DISTINCT insumo_id, insumo_nome, quantidade_total
    FROM insumos_consolidados
  LOOP
    v_quantidade_necessaria := v_insumo_record.quantidade_total * p_quantidade;

    -- Iterar sobre lotes em ordem FIFO (created_at ASC)
    FOR v_lote_record IN
      SELECT id, quantidade_atual, created_at
      FROM lotes
      WHERE insumo_id = v_insumo_record.insumo_id
      ORDER BY created_at ASC
    LOOP
      EXIT WHEN v_quantidade_necessaria <= 0;

      -- Calcular quanto deduzir deste lote
      v_quantidade_a_deduzir := LEAST(v_lote_record.quantidade_atual, v_quantidade_necessaria);
      v_nova_quantidade_lote := v_lote_record.quantidade_atual - v_quantidade_a_deduzir;

      -- Atualizar quantidade do lote
      UPDATE lotes
      SET quantidade_atual = v_nova_quantidade_lote
      WHERE id = v_lote_record.id;

      -- Registrar movimento de consumo
      INSERT INTO baixa_estoque (
        lote_id,
        quantidade_baixada,
        motivo,
        data_baixa,
        referencia_producao_id,
        tipo_movimentacao
      ) VALUES (
        v_lote_record.id,
        v_quantidade_a_deduzir,
        'producao',
        NOW(),
        p_ordem_id,
        'consumo_producao'
      );

      v_quantidade_necessaria := v_quantidade_necessaria - v_quantidade_a_deduzir;
    END LOOP;

    -- Validação extra: se ainda falta quantidade, algo deu errado
    IF v_quantidade_necessaria > 0 THEN
      RAISE EXCEPTION 'Erro ao deduzir estoque: quantidade insuficiente de %', v_insumo_record.insumo_nome;
    END IF;
  END LOOP;

  -- ========================================================================
  -- PASSO 5: Atualizar status da ordem para 'em_andamento'
  -- ========================================================================
  UPDATE ordens_producao
  SET 
    status = 'em_andamento',
    data_inicio = NOW(),
    updated_at = NOW()
  WHERE id = p_ordem_id;

  -- ========================================================================
  -- PASSO 6: Retornar sucesso
  -- ========================================================================
  RETURN JSON_BUILD_OBJECT(
    'success', TRUE,
    'message', 'Produção iniciada com sucesso',
    'ordem_id', p_ordem_id,
    'data_inicio', NOW()
  );

EXCEPTION WHEN OTHERS THEN
  -- Qualquer erro causa ROLLBACK automático da transação
  RETURN JSON_BUILD_OBJECT(
    'success', FALSE,
    'message', 'Erro ao iniciar produção: ' || SQLERRM,
    'error_code', SQLSTATE
  );
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- Comentários sobre a RPC:
-- ============================================================================
-- 
-- 1. ATOMICIDADE:
--    - Toda a função é executada dentro de uma transação implícita
--    - Qualquer erro (RAISE EXCEPTION ou constraint violation) causa ROLLBACK
--    - Nenhuma alteração parcial é possível
--
-- 2. VALIDAÇÃO:
--    - Verifica se ordem existe e está em status 'pendente'
--    - Consolida insumos de fichas técnicas + insumos separados com CTE
--    - Valida estoque total de cada insumo
--    - Retorna lista estruturada de déficits se falhar
--
-- 3. DEDUÇÃO FIFO:
--    - Ordena lotes por created_at ASC (mais antigos primeiro)
--    - Deduz quantidade necessária lote por lote
--    - Registra cada movimento em baixa_estoque com tipo 'consumo_producao'
--
-- 4. RASTREABILIDADE:
--    - Cada movimento é registrado com:
--      - lote_id: qual lote foi consumido
--      - quantidade_baixada: quanto foi consumido
--      - referencia_producao_id: qual ordem consumiu
--      - tipo_movimentacao: 'consumo_producao'
--
-- 5. ERRO HANDLING:
--    - EXCEPTION WHEN OTHERS captura qualquer erro
--    - Retorna mensagem estruturada com SQLERRM e SQLSTATE
--    - ROLLBACK é automático
--
-- 6. CTE (Common Table Expressions):
--    - insumos_fichas: Insumos das fichas técnicas
--    - insumos_separados: Insumos adicionados separadamente
--    - insumos_consolidados: União com SUM para tratar duplicidade
--    - insumos_com_estoque: Cálculo final com estoque disponível

