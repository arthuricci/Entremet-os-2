# ALINHAMENTO ARQUITETURAL - MOTOR DE PRODUÇÃO
## Decisões Críticas Antes da Implementação

---

## 1️⃣ MODELO DEFINITIVO DE ESTADOS DA PRODUÇÃO

### Campo Único Responsável pelo Estado:
**Campo:** `status` (string enum)
**Tabela:** `ordens_producao`
**Localização no código:** `server/supabaseClient.ts`, linha 137

### Valores Permitidos (DEFINITIVOS):
```typescript
type StatusProducao = 'pendente' | 'em_andamento' | 'concluida' | 'cancelada'
```

**Descrição de cada estado:**

| Estado | Significado | Quando Ocorre | Pode Transicionar Para |
|--------|------------|---------------|----------------------|
| `pendente` | Ordem criada, não iniciada | Ao criar ordem | `em_andamento` |
| `em_andamento` | Ordem iniciada, estoque deduzido | Ao clicar "Iniciar Produção" | `concluida`, `cancelada` |
| `concluida` | Produção finalizada | Ao clicar "Finalizar Produção" | ❌ NENHUMA |
| `cancelada` | Produção cancelada, estoque estornado | Ao clicar "Cancelar Produção" | ❌ NENHUMA |

### Transições Permitidas (EXPLÍCITAS):

```
pendente ──→ em_andamento ✅
pendente ──→ concluida ❌ (BLOQUEADO)
pendente ──→ cancelada ❌ (BLOQUEADO)

em_andamento ──→ concluida ✅
em_andamento ──→ cancelada ✅
em_andamento ──→ pendente ❌ (BLOQUEADO)

concluida ──→ qualquer ❌ (BLOQUEADO - estado terminal)
cancelada ──→ qualquer ❌ (BLOQUEADO - estado terminal)
```

### Transições Proibidas (EXEMPLOS CONCRETOS):

**❌ Exemplo 1: Finalizar sem iniciar**
```typescript
// BLOQUEADO
IF status = 'pendente' AND tentativa_finalizar THEN
  throw new Error('Produção não foi iniciada');
```

**❌ Exemplo 2: Cancelar produção já finalizada**
```typescript
// BLOQUEADO
IF status = 'concluida' AND tentativa_cancelar THEN
  throw new Error('Produção já foi concluída, não pode ser cancelada');
```

**❌ Exemplo 3: Iniciar produção já iniciada**
```typescript
// BLOQUEADO
IF status = 'em_andamento' AND tentativa_iniciar THEN
  throw new Error('Produção já foi iniciada');
```

**❌ Exemplo 4: Finalizar produção cancelada**
```typescript
// BLOQUEADO
IF status = 'cancelada' AND tentativa_finalizar THEN
  throw new Error('Produção foi cancelada, não pode ser finalizada');
```

### Fonte Única de Verdade:
- **Campo único:** `ordens_producao.status`
- **Sem campos redundantes:** Não existem outros campos que indiquem estado (ex: não há `is_started`, `is_cancelled`, etc.)
- **Sem lógica implícita:** O estado é sempre explícito no banco

### Impacto Técnico:
- ✅ Sem ambiguidade de estado
- ✅ Transições validadas antes de execução
- ✅ Impossível ter ordem em estado inconsistente
- ✅ Auditoria clara de mudanças de estado

---

## 2️⃣ ATOMICIDADE DO INÍCIO DA PRODUÇÃO (CRÍTICO)

### Operações que Devem Ser Atômicas:

```
OPERAÇÃO: Iniciar Produção
├─ 1. Validar insumos
├─ 2. Deduzir estoque
└─ 3. Mudar status para 'em_andamento'
```

### Como Será Garantida a Atomicidade:

**Abordagem:** Transação de banco de dados (Supabase + PostgreSQL)

#### Implementação Técnica:

```typescript
// Pseudocódigo da transação
BEGIN TRANSACTION

  // PASSO 1: Validação (leitura)
  SELECT * FROM lotes WHERE insumo_id IN (...)
  // Verificar se quantidade_atual >= necessário
  // Se falhar: ROLLBACK, nenhuma alteração

  // PASSO 2: Dedução de estoque (escrita)
  UPDATE lotes SET quantidade_atual = quantidade_atual - ?
  // Criar registros em baixa_estoque
  INSERT INTO baixa_estoque (...)
  // Se falhar: ROLLBACK, nenhuma alteração

  // PASSO 3: Mudança de status (escrita)
  UPDATE ordens_producao SET status = 'em_andamento', data_inicio = NOW()
  // Se falhar: ROLLBACK, nenhuma alteração

COMMIT TRANSACTION
```

### Mecanismo Disponível no Stack Atual:

**Supabase (PostgreSQL)** suporta transações nativas via:
1. **RPC (Remote Procedure Call):** Função SQL no banco
2. **Transações explícitas:** `BEGIN`, `COMMIT`, `ROLLBACK`
3. **Triggers:** Validações automáticas

**Decisão de implementação:**
- ✅ Usar **RPC (Remote Procedure Call) no Supabase**
- Razão: Executa toda a lógica no banco, garantindo atomicidade
- Alternativa: Transação manual via cliente (menos segura)

### Comportamento em Caso de Falha:

#### Cenário 1: Falha na Validação
```
Falha: Estoque insuficiente
├─ Nenhuma linha é alterada
├─ Status permanece 'pendente'
├─ Erro retornado ao frontend
└─ Usuário vê mensagem: "Estoque insuficiente de [insumo]"
```

#### Cenário 2: Falha na Dedução
```
Falha: Erro ao atualizar lote (ex: conexão perdida)
├─ Transação inteira é revertida
├─ Lotes não são alterados
├─ Status permanece 'pendente'
├─ Erro retornado ao frontend
└─ Usuário pode tentar novamente
```

#### Cenário 3: Falha na Atualização de Status
```
Falha: Erro ao atualizar ordens_producao
├─ Transação inteira é revertida
├─ Lotes voltam ao estado anterior
├─ Status permanece 'pendente'
├─ Erro retornado ao frontend
└─ Sistema fica consistente
```

### Garantias de Atomicidade:

| Garantia | Como é Garantida |
|----------|-----------------|
| **Tudo ou nada** | Transação ACID do PostgreSQL |
| **Sem estado intermediário** | Falha = ROLLBACK automático |
| **Sem dupla dedução** | Transação bloqueia leitura concorrente |
| **Sem inconsistência** | Validação + Dedução + Status em uma operação |

### Impacto Técnico:

- ✅ **Integridade garantida:** Impossível ficar em estado inconsistente
- ✅ **Sem race conditions:** Transação bloqueia operações concorrentes
- ✅ **Recuperação automática:** Falha = tudo revertido
- ✅ **Auditoria completa:** Cada movimento é registrado ou nenhum é

---

## 3️⃣ REGRA EXPLÍCITA DE CONSUMO DE LOTES

### Critério de Ordenação (FIFO):
**Método:** First-In-First-Out (Primeiro a Entrar, Primeiro a Sair)

### Campo de Ordenação:
**Campo:** `created_at` (timestamp de criação do lote)
**Tabela:** `lotes`
**Ordem:** ASC (crescente = mais antigos primeiro)

### Definição Técnica Inequívoca:

```sql
-- Ordenação para consumo
SELECT * FROM lotes 
WHERE insumo_id = ?
ORDER BY created_at ASC
-- Resultado: Lotes mais antigos primeiro
```

### Por Que Essa Escolha é Consistente:

#### Razão 1: Validade
- Lotes mais antigos têm maior risco de vencer
- Consumir antigos primeiro reduz desperdício
- Alinhado com boas práticas de estoque

#### Razão 2: Rastreabilidade
- `created_at` é imutável e confiável
- Não pode ser alterado após criação
- Garante ordem consistente sempre

#### Razão 3: Simplicidade
- Campo existe em todas as tabelas
- Sem necessidade de lógica complexa
- Fácil de auditar e verificar

#### Razão 4: Existência no Sistema
- Campo `created_at` já existe em `lotes`
- Não requer mudanças no schema
- Funciona com dados atuais

### Algoritmo de Consumo (PASSO A PASSO):

```typescript
// 1. Buscar lotes do insumo, ordenados por criação
const lotesOrdenados = await supabase
  .from('lotes')
  .select('*')
  .eq('insumo_id', insumoId)
  .order('created_at', { ascending: true });  // FIFO

// 2. Consumir em ordem
let quantidadeAindaNecessaria = quantidadeTotal;

for (const lote of lotesOrdenados) {
  if (quantidadeAindaNecessaria <= 0) break;
  
  const quantidadeDisponivel = lote.quantidade_atual;
  const quantidadeAConsumirDesseLote = Math.min(
    quantidadeDisponivel,
    quantidadeAindaNecessaria
  );
  
  // 3. Deduzir do lote
  const novaQuantidade = quantidadeDisponivel - quantidadeAConsumirDesseLote;
  await updateLote(lote.id, { quantidade_atual: novaQuantidade });
  
  // 4. Registrar movimento
  await createBaixaEstoque({
    lote_id: lote.id,
    quantidade_baixada: quantidadeAConsumirDesseLote,
    motivo: 'producao',
    referencia_producao_id: ordemId,
  });
  
  quantidadeAindaNecessaria -= quantidadeAConsumirDesseLote;
}

// 5. Validar se consumiu tudo
if (quantidadeAindaNecessaria > 0) {
  throw new Error('Estoque insuficiente');
}
```

### Exemplo Concreto:

**Cenário:** Produzir 500g de farinha

**Estoque disponível:**
```
Lote A: 100g (criado em 2025-01-01)
Lote B: 200g (criado em 2025-01-05)
Lote C: 300g (criado em 2025-01-10)
```

**Ordem de consumo (FIFO por created_at):**
```
1. Lote A (100g) → Consome 100g → Restam 400g necessários
2. Lote B (200g) → Consome 200g → Restam 200g necessários
3. Lote C (300g) → Consome 200g → Restam 0g necessários ✅

Resultado:
├─ Lote A: 100g → 0g (consumido totalmente)
├─ Lote B: 200g → 0g (consumido totalmente)
└─ Lote C: 300g → 100g (consumido parcialmente)
```

### Impacto Técnico:

- ✅ **Determinístico:** Sempre consome na mesma ordem
- ✅ **Auditável:** Cada consumo é registrado com lote_id
- ✅ **Reversível:** Estorno recupera lotes exatos
- ✅ **Consistente:** Sem ambiguidade de qual lote consumir

---

## 4️⃣ COMPORTAMENTO DA FINALIZAÇÃO DA PRODUÇÃO

### O Que Acontece Ao Finalizar:

**Ação:** Marcar produção como `concluida`

**Escopo DEFINIDO (será implementado agora):**
- ✅ Mudança de status de `em_andamento` para `concluida`
- ✅ Registro de data/hora de conclusão
- ✅ Nenhuma alteração adicional de estoque

**Escopo FORA DO ESCOPO (não será implementado agora):**
- ❌ Criação de lote de produto final
- ❌ Geração de produto acabado em estoque
- ❌ Movimentação para outro depósito
- ❌ Cálculo de custo de produção

### Tabelas Afetadas:

| Tabela | Campo | Operação | Motivo |
|--------|-------|----------|--------|
| `ordens_producao` | `status` | UPDATE | Marcar como concluída |
| `ordens_producao` | `data_conclusao` | UPDATE | Registrar quando finalizou |

### Campos Alterados (EXATAMENTE):

```typescript
UPDATE ordens_producao 
SET 
  status = 'concluida',
  data_conclusao = NOW(),
  updated_at = NOW()
WHERE id = ?
```

### Validações Antes de Finalizar:

```typescript
// BLOQUEIO 1: Só finaliza se iniciada
IF ordem.status !== 'em_andamento' THEN
  throw new Error('Produção não foi iniciada');

// BLOQUEIO 2: Não finaliza se cancelada
IF ordem.status === 'cancelada' THEN
  throw new Error('Produção foi cancelada');

// BLOQUEIO 3: Não finaliza se já concluída
IF ordem.status === 'concluida' THEN
  throw new Error('Produção já foi concluída');
```

### O Que NÃO Acontece (EXPLÍCITO):

```typescript
// ❌ NÃO cria lote de produto final
// ❌ NÃO gera estoque de produto acabado
// ❌ NÃO calcula custo de produção
// ❌ NÃO cria movimentação de estoque
// ❌ NÃO altera quantidade de nenhum lote
// ❌ NÃO cria registro em baixa_estoque
```

### Impacto Técnico:

- ✅ **Simples:** Apenas mudança de status
- ✅ **Seguro:** Sem efeitos colaterais
- ✅ **Extensível:** Futuro pode adicionar lógica sem quebrar
- ✅ **Auditável:** Data de conclusão registrada

### Fluxo Completo de Produção (DEFINIDO):

```
1. CRIAR ORDEM
   └─ status = 'pendente'

2. INICIAR PRODUÇÃO
   ├─ Validar insumos (transação)
   ├─ Deduzir estoque (transação)
   ├─ Criar registros de baixa (transação)
   └─ status = 'em_andamento', data_inicio = NOW()

3. FINALIZAR PRODUÇÃO
   ├─ Validar status = 'em_andamento'
   └─ status = 'concluida', data_conclusao = NOW()

4. CANCELAR PRODUÇÃO (alternativa a 3)
   ├─ Validar status = 'em_andamento'
   ├─ Encontrar todos os consumos
   ├─ Estornar para lotes (transação)
   ├─ Criar registros de estorno (transação)
   └─ status = 'cancelada', data_cancelamento = NOW()
```

---

## RESUMO EXECUTIVO DE DECISÕES ARQUITETURAIS

### 1. Estados (Fonte Única de Verdade):
```
Campo: ordens_producao.status
Valores: 'pendente' | 'em_andamento' | 'concluida' | 'cancelada'
Transições: Explicitamente definidas e bloqueadas
```

### 2. Atomicidade (Garantia de Integridade):
```
Mecanismo: Transação PostgreSQL (RPC no Supabase)
Escopo: Validação + Dedução + Mudança de Status
Falha: ROLLBACK automático, sem estado intermediário
```

### 3. Consumo de Lotes (Determinístico):
```
Método: FIFO (First-In-First-Out)
Campo: created_at (ASC)
Razão: Validade, rastreabilidade, simplicidade
```

### 4. Finalização (Escopo Limitado):
```
Ação: Mudança de status + Data de conclusão
Tabelas: Apenas ordens_producao
Fora do escopo: Lote de produto final, estoque de acabado
```

### Impacto Geral:
- ✅ **Integridade:** Impossível estado inconsistente
- ✅ **Rastreabilidade:** Cada ação registrada
- ✅ **Determinismo:** Comportamento previsível
- ✅ **Segurança:** Transações ACID
- ✅ **Extensibilidade:** Pronto para futuras expansões

---

## PRÓXIMOS PASSOS (APÓS VALIDAÇÃO):

1. ✅ Validar alinhamento arquitetural com usuário
2. ⏳ Aguardar autorização para implementação
3. ⏳ Implementar conforme decisões acima
4. ⏳ Testar atomicidade e transições
5. ⏳ Validar com usuário

