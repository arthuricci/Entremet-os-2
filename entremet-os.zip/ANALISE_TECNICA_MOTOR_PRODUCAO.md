# ANÁLISE TÉCNICA - MOTOR DE PRODUÇÃO
## Resposta ao Questionário Técnico Obrigatório

---

## 1️⃣ MAPEAMENTO REAL DE DADOS

### Entidades/Tabelas Utilizadas no Sistema Atual:

#### A) **ordens_producao** (Tabela Principal de Produção)
**Campos existentes:**
- `id` (UUID, PK)
- `produto_id` (UUID, FK → produtos_venda)
- `status` (ENUM: 'pendente' | 'em_andamento' | 'concluida')
- `quantidade_produzida` (number)
- `data_inicio` (timestamp)
- `data_conclusao` (timestamp | null)
- `created_at` (timestamp)
- `updated_at` (timestamp)

**Campos que serão LIDOS:**
- `id`, `produto_id`, `status`, `quantidade_produzida`, `data_inicio`

**Campos que serão ESCRITOS:**
- `status` (para 'em_andamento' e 'concluida')
- `data_inicio` (ao iniciar)
- `data_conclusao` (ao finalizar)

**Campos NOVOS necessários:**
- `status_cancelamento` (ENUM: null | 'cancelada') - para rastrear cancelamentos
- `data_cancelamento` (timestamp | null) - quando foi cancelada

---

#### B) **produtos_venda** (Produto a Produzir)
**Campos existentes:**
- `id` (UUID, PK)
- `nome` (string)
- `descricao` (string | null)
- `preco_venda` (number | null)
- `foto_url` (string | null)
- `ativo` (boolean)
- `ficha_tecnica_id` (UUID | null, FK → fichas_tecnicas)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `id`, `nome`, `ficha_tecnica_id`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### C) **fichas_tecnicas** (Receita/Fórmula)
**Campos existentes:**
- `id` (UUID, PK)
- `nome` (string | null)
- `modo_de_preparo` (string | null)
- `rendimento_total` (number | null)
- `unidade_rendimento` (string | null)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `id`, `nome`, `rendimento_total`, `unidade_rendimento`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### D) **ingredientes** (Itens da Ficha Técnica)
**Campos existentes:**
- `id` (UUID, PK)
- `ficha_tecnica_id` (UUID, FK → fichas_tecnicas)
- `insumo_id` (UUID, FK → Insumos)
- `quantidade` (number | null)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `ficha_tecnica_id`, `insumo_id`, `quantidade`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### E) **produto_insumo** (Insumos Adicionados Separadamente ao Produto)
**Campos existentes:**
- `id` (UUID, PK)
- `produto_id` (UUID, FK → produtos_venda)
- `insumo_id` (UUID, FK → Insumos)
- `quantidade` (number)
- `unidade` (string | null)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `produto_id`, `insumo_id`, `quantidade`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### F) **produto_fichas_tecnicas** (Relacionamento N:N Produto ↔ Ficha)
**Campos existentes:**
- `id` (UUID, PK)
- `produto_id` (UUID, FK → produtos_venda)
- `ficha_tecnica_id` (UUID, FK → fichas_tecnicas)
- `quantidade` (numeric) - quantidade de vezes que a ficha é usada
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `produto_id`, `ficha_tecnica_id`, `quantidade`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### G) **Insumos** (Matéria Prima)
**Campos existentes:**
- `id` (UUID, PK)
- `nome` (string)
- `unidade_base` (string)
- `nivel_minimo` (number)
- `tipo_produto` (string | null)
- `preco_medio_por_unidade` (number | null)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `id`, `nome`, `unidade_base`, `preco_medio_por_unidade`

**Campos que serão ESCRITOS:**
- Nenhum

---

#### H) **lotes** (Estoque - Lotes de Insumos)
**Campos existentes:**
- `id` (UUID, PK)
- `insumo_id` (UUID, FK → Insumos)
- `quantidade_inicial` (number | null)
- `quantidade_atual` (number | null)
- `data_de_validade` (string | null)
- `custo_total_lote` (number | null)
- `preco_por_unidade` (number | null)
- `created_at`, `updated_at`

**Campos que serão LIDOS:**
- `id`, `insumo_id`, `quantidade_atual`, `created_at`

**Campos que serão ESCRITOS:**
- `quantidade_atual` (ao deduzir estoque)

---

#### I) **baixa_estoque** (Registro de Movimentação)
**Campos existentes:**
- `id` (UUID, PK)
- `lote_id` (UUID, FK → lotes)
- `quantidade_baixada` (number | null)
- `motivo` (string | null) - ex: 'producao', 'desperdicio', 'estorno'
- `data_baixa` (timestamp | null)
- `referencia_producao_id` (UUID | null, FK → ordens_producao)
- `created_at`

**Campos que serão LIDOS:**
- `lote_id`, `quantidade_baixada`, `motivo`, `referencia_producao_id`

**Campos que serão ESCRITOS:**
- Todos (novo registro a cada movimentação)

**Campos NOVOS necessários:**
- `tipo_movimentacao` (ENUM: 'consumo' | 'estorno') - para diferenciar deduções de estornos
- `data_estorno` (timestamp | null) - quando foi estornado

---

### Resumo de Tabelas:
| Tabela | Função | Leitura | Escrita |
|--------|--------|---------|---------|
| ordens_producao | Controle de produção | ✅ | ✅ (status, datas) |
| produtos_venda | Produto a produzir | ✅ | ❌ |
| fichas_tecnicas | Receita/fórmula | ✅ | ❌ |
| ingredientes | Itens da ficha | ✅ | ❌ |
| produto_insumo | Insumos separados | ✅ | ❌ |
| produto_fichas_tecnicas | Vinculação N:N | ✅ | ❌ |
| Insumos | Matéria prima | ✅ | ❌ |
| lotes | Estoque atual | ✅ | ✅ (quantidade_atual) |
| baixa_estoque | Auditoria | ✅ | ✅ (novos registros) |

---

## 2️⃣ PONTO EXATO DO FLUXO DE INÍCIO DA PRODUÇÃO

### Fluxo Atual:
1. **Ação que inicia produção:** Clique em botão "Iniciar Produção" na página `/ordens-producao`
2. **Função frontend que dispara:** `handleStartProduction()` em `OrdenProducaoList.tsx`
3. **Procedure tRPC chamado:** `ordensProducao.startProduction` (linha 657 em routers.ts)

### Ponto de Interceptação:
**Localização exata:** `server/routers.ts`, linhas 657-677, na procedure `startProduction`

**Fluxo atual:**
```typescript
startProduction: publicProcedure
  .input(z.object({
    ordemId: z.string().uuid(),
    produtoId: z.string().uuid(),
    quantidade: z.number().min(0),
  }))
  .mutation(async ({ input }) => {
    // 1. Validação de estoque
    const validation = await validateStockForProduction(input.produtoId, input.quantidade);
    
    // 2. Se válido, deduz estoque
    if (!validation.isValid) {
      throw new Error(validation.message);
    }
    
    const deduction = await deductStockForProduction(input.ordemId, input.produtoId, input.quantidade);
    
    // 3. Atualiza status da ordem
    if (!deduction.success) {
      throw new Error(deduction.message);
    }
    
    await updateOrdemProducao(input.ordemId, {
      status: 'em_andamento',
      data_inicio: new Date().toISOString(),
    });
    
    return { success: true };
  })
```

### Onde a Validação Será Executada:
**Função:** `validateStockForProduction()` (linha 957 em db.ts)

**Bloqueio em caso de erro:**
- A procedure lança `throw new Error()` se `validation.isValid === false`
- Frontend recebe erro e exibe mensagem ao usuário
- **Nenhuma ordem é criada, nenhum estoque é deduzido**

---

## 3️⃣ ALGORITMO DE CÁLCULO DE INSUMOS (PASSO A PASSO)

### Algoritmo Completo de Coleta de Insumos:

```
ENTRADA: produtoId, quantidade_a_produzir

PASSO 1: Carregar fichas técnicas do produto
  - Query: produto_fichas_tecnicas WHERE produto_id = produtoId
  - Retorna: [{ ficha_tecnica_id, quantidade }, ...]
  - Função: getProductFichasTecnicas(produtoId)

PASSO 2: Para cada ficha técnica, carregar ingredientes
  - Query: ingredientes WHERE ficha_tecnica_id = ficha.id
  - Retorna: [{ insumo_id, quantidade }, ...]
  - Função: getIngredientesByFicha(ficha.id)
  - Multiplicar quantidade por ficha.quantidade (se houver)

PASSO 3: Carregar insumos adicionados separadamente ao produto
  - Query: produto_insumo WHERE produto_id = produtoId
  - Retorna: [{ insumo_id, quantidade }, ...]
  - Função: getProdutoInsumos(produtoId)

PASSO 4: Unificar insumos em estrutura única
  - Criar Map: { insumo_id → { quantidade_total, insumo_obj } }
  - Somar quantidades de fichas + insumos separados
  - Tratamento de duplicidade: SUM(quantidade) por insumo_id

PASSO 5: Calcular quantidade necessária por insumo
  - Para cada insumo_id no mapa:
    quantidade_necessaria = quantidade_total × quantidade_a_produzir
  - Exemplo:
    - Ficha 1 tem 100g de farinha
    - Insumo separado tem 50g de farinha
    - Total: 150g por unidade produzida
    - Se produzir 10 unidades: 150 × 10 = 1500g necessários

SAÍDA: Array de insumos com quantidade necessária
  [
    { insumo_id, insumo_nome, quantidade_necessaria, unidade },
    ...
  ]
```

### Funções Envolvidas:
1. `getProductFichasTecnicas(produtoId)` - linha 934 em db.ts
2. `getIngredientesByFicha(fichaId)` - busca ingredientes da ficha
3. `getProdutoInsumos(produtoId)` - busca insumos separados
4. `validateStockForProduction()` - linha 957 em db.ts (orquestra tudo)

### Tratamento de Duplicidade:
**Exemplo prático:**
- Ficha 1: 100g de farinha
- Ficha 2: 50g de farinha
- Insumo separado: 25g de farinha
- **Total unificado:** 175g de farinha por unidade

**Implementação:**
```typescript
const insumosMap = new Map();

for (const ficha of fichas) {
  const ingredientes = await getIngredientesByFicha(ficha.id);
  for (const ing of ingredientes) {
    const chave = ing.insumo_id;
    if (!insumosMap.has(chave)) {
      insumosMap.set(chave, { quantidade: 0, insumo: ing.insumo });
    }
    insumosMap.get(chave).quantidade += ing.quantidade;
  }
}

// Adicionar insumos separados
const insumosSeparados = await getProdutoInsumos(produtoId);
for (const ins of insumosSeparados) {
  const chave = ins.insumo_id;
  if (!insumosMap.has(chave)) {
    insumosMap.set(chave, { quantidade: 0, insumo: ins.insumo });
  }
  insumosMap.get(chave).quantidade += ins.quantidade;
}

// Multiplicar pela quantidade a produzir
for (const [insumoId, dados] of insumosMap) {
  dados.quantidade_necessaria = dados.quantidade * quantidade_a_produzir;
}
```

---

## 4️⃣ VALIDAÇÃO DE ESTOQUE (NÍVEL DE BANCO)

### De Onde Vem o Valor Atual do Estoque:

**Fonte:** Tabela `lotes` (estoque em lotes)

**Cálculo dinâmico:**
```sql
SELECT 
  insumo_id,
  SUM(quantidade_atual) as estoque_disponivel
FROM lotes
WHERE insumo_id = ?
GROUP BY insumo_id
```

**Função:** `validateStockForProduction()` (linha 957 em db.ts)

```typescript
// Get all batches (lotes)
const lotes = await getLotes();

// Validate stock for each ingredient
for (const ingrediente of ingredientesNecessarios) {
  const quantidadeNecessaria = (ingrediente.quantidade || 0) * quantidade;
  
  // Get total available stock for this ingredient
  const lotesDoInsumo = lotes.filter((lote: any) => 
    lote.insumo_id === ingrediente.insumo_id
  );
  const quantidadeDisponivel = lotesDoInsumo.reduce(
    (sum: number, lote: any) => sum + (lote.quantidade_atual || 0), 
    0
  );

  if (quantidadeDisponivel < quantidadeNecessaria) {
    return {
      isValid: false,
      message: `Estoque insuficiente de ${ingrediente.insumo?.nome}: 
                necessário ${quantidadeNecessaria}, 
                disponível ${quantidadeDisponivel}`,
    };
  }
}
```

### Como Garantir Valor Atualizado:
1. **Leitura em tempo real:** `getLotes()` sempre busca dados atuais do Supabase
2. **Sem cache:** Cada chamada faz query nova ao banco
3. **Transação implícita:** Supabase garante leitura consistente

### Operador Lógico de Validação:
```
IF (quantidadeDisponivel < quantidadeNecessaria) THEN
  REJECT
ELSE
  ALLOW
```

### Formato Exato do Retorno de Erro:
```typescript
{
  isValid: false,
  message: string,  // Mensagem legível com nome do insumo e quantidades
  ingredientesNecessarios?: any[]  // Array de ingredientes que faltam
}
```

---

## 5️⃣ CONTROLE DE DUPLA BAIXA

### Como o Sistema Impede Baixa Duplicada:

#### A) **Flags de Status:**
- Tabela `ordens_producao` tem campo `status`:
  - `'pendente'` → não iniciada
  - `'em_andamento'` → iniciada, estoque deduzido
  - `'concluida'` → finalizada
  - `'cancelada'` (NOVO) → cancelada, estoque estornado

#### B) **Lógica de Proteção:**
```typescript
// No startProduction:
const validation = await validateStockForProduction(...);
if (!validation.isValid) {
  throw new Error(...);  // BLOQUEIA
}

// Se passou validação, deduz
const deduction = await deductStockForProduction(...);
if (!deduction.success) {
  throw new Error(...);  // BLOQUEIA
}

// Só depois atualiza status
await updateOrdemProducao(ordemId, { status: 'em_andamento' });
```

#### C) **O que Acontece em Cliques Repetidos:**
1. **Primeiro clique:** 
   - Validação ✅ → Dedução ✅ → Status = 'em_andamento'
   
2. **Segundo clique (mesmo ordemId):**
   - `validateStockForProduction()` é chamado novamente
   - Estoque já foi deduzido → quantidade_atual reduzida
   - Validação falha ❌ → Erro lançado
   - **Nenhuma dedução adicional ocorre**

#### D) **Proteção Adicional Necessária:**
Adicionar verificação de status antes de iniciar:
```typescript
// Antes de validar, verificar se já está em andamento
const ordem = await getOrdemProducaoById(ordemId);
if (ordem.status === 'em_andamento') {
  throw new Error('Produção já foi iniciada');
}
if (ordem.status === 'concluida') {
  throw new Error('Produção já foi concluída');
}
if (ordem.status === 'cancelada') {
  throw new Error('Produção foi cancelada');
}
```

---

## 6️⃣ MODELO DE MOVIMENTAÇÃO DE ESTOQUE

### Tipo de Movimentação Criada no Início:

**Tabela:** `baixa_estoque`

**Registro criado para cada lote consumido:**
```typescript
{
  id: UUID (gerado),
  lote_id: UUID,  // Qual lote foi consumido
  quantidade_baixada: number,  // Quanto foi consumido
  motivo: 'producao',  // Tipo de movimento
  data_baixa: timestamp,  // Quando foi consumido
  referencia_producao_id: UUID,  // ID da ordem de produção
  tipo_movimentacao: 'consumo',  // NOVO: diferencia consumo de estorno
  created_at: timestamp
}
```

### Campos que Indicam Origem/Referência:

| Campo | Significado |
|-------|------------|
| `motivo` | 'producao' = consumido em produção |
| `referencia_producao_id` | ID da ordem_producao que consumiu |
| `tipo_movimentacao` | 'consumo' = dedução / 'estorno' = devolução |
| `data_baixa` | Quando ocorreu |

### Como Essas Movimentações Serão Usadas:

1. **Auditoria:** Rastrear cada consumo até a ordem específica
2. **Reversão:** Encontrar todos os registros de uma ordem cancelada
3. **Relatório:** Somar consumos por período/produto
4. **Validação:** Impedir dupla dedução (status + histórico)

---

## 7️⃣ CANCELAMENTO DE PRODUÇÃO (REVERSÃO REAL)

### Como Identificar Produções Canceláveis:

```typescript
// Uma produção é cancelável se:
// 1. Status = 'em_andamento' (foi iniciada)
// 2. Status ≠ 'concluida' (não foi finalizada)
// 3. Status ≠ 'cancelada' (não foi já cancelada)

if (ordem.status !== 'em_andamento') {
  throw new Error('Só produções em andamento podem ser canceladas');
}
```

### Como Recuperar Insumos Debitados:

**Passo 1:** Encontrar todos os registros de consumo
```sql
SELECT * FROM baixa_estoque 
WHERE referencia_producao_id = ? 
  AND tipo_movimentacao = 'consumo'
```

**Passo 2:** Para cada consumo, recuperar quantidade
```typescript
const consumos = await supabase
  .from('baixa_estoque')
  .select('lote_id, quantidade_baixada')
  .eq('referencia_producao_id', ordemId)
  .eq('tipo_movimentacao', 'consumo');
```

### Como Executar o Estorno:

**Para cada consumo:**
```typescript
for (const consumo of consumos) {
  // 1. Recuperar quantidade no lote
  const lote = await getLoteById(consumo.lote_id);
  
  // 2. Adicionar quantidade de volta
  const novaQuantidade = lote.quantidade_atual + consumo.quantidade_baixada;
  await updateLote(consumo.lote_id, { 
    quantidade_atual: novaQuantidade 
  });
  
  // 3. Registrar estorno
  await createBaixaEstoque({
    lote_id: consumo.lote_id,
    quantidade_baixada: consumo.quantidade_baixada,
    motivo: 'estorno_producao',
    tipo_movimentacao: 'estorno',
    referencia_producao_id: ordemId,
    data_baixa: new Date().toISOString(),
  });
}

// 4. Marcar ordem como cancelada
await updateOrdemProducao(ordemId, {
  status: 'cancelada',
  data_cancelamento: new Date().toISOString(),
});
```

### Como Impedir Novo Cancelamento:

```typescript
// Verificar se já foi cancelada
if (ordem.status === 'cancelada') {
  throw new Error('Produção já foi cancelada');
}
```

### Como Impedir Finalização Após Cancelamento:

```typescript
// Na procedure finalizarProducao:
if (ordem.status === 'cancelada') {
  throw new Error('Não é possível finalizar uma produção cancelada');
}
```

---

## 8️⃣ PRODUÇÃO SEM VÍNCULO EXTERNO

### Por Que Esse Fluxo Não Depende de Outros Módulos:

1. **Dados independentes:**
   - Ordem de produção existe isoladamente
   - Não depende de pedidos, vendas ou clientes
   - Pode ser criada manualmente para estoque

2. **Produto é autossuficiente:**
   - Tem fichas técnicas vinculadas
   - Tem insumos separados
   - Pode produzir sem vínculo externo

3. **Estoque é gerenciado internamente:**
   - Lotes existem independentemente
   - Movimentações são registradas localmente
   - Não precisa sincronizar com sistema externo

### Como Produções para Estoque Continuam Funcionando:

```typescript
// Produção para estoque (sem vínculo):
{
  produto_id: 'uuid-produto',
  status: 'pendente',
  quantidade_produzida: 100,
  data_inicio: null,
  data_conclusao: null
}

// Fluxo é exatamente o mesmo:
// 1. Validar estoque
// 2. Deduzir estoque
// 3. Marcar como em_andamento
// 4. Finalizar
// 5. Marcar como concluida
```

### Quais Dados Permanecem Independentes:

| Dado | Independência |
|------|--------------|
| Ordem de produção | ✅ Existe sozinha |
| Produto | ✅ Não depende de pedido |
| Fichas técnicas | ✅ Reutilizáveis |
| Insumos | ✅ Gerenciados internamente |
| Estoque (lotes) | ✅ Independente |
| Movimentações | ✅ Registradas localmente |

---

## 9️⃣ INVARIANTES DO SISTEMA (REGRAS INVIOLÁVEIS)

### Regra 1: Estoque Nunca Negativo
```
INVARIANTE: lotes.quantidade_atual >= 0 (sempre)
PROTEÇÃO: Validação antes de dedução
VERIFICAÇÃO: SELECT quantidade_atual FROM lotes WHERE quantidade_atual < 0
```

### Regra 2: Produção Cancelada Não Finaliza
```
INVARIANTE: IF status = 'cancelada' THEN não pode ser 'concluida'
PROTEÇÃO: Verificar status antes de finalizar
VERIFICAÇÃO: UPDATE ordens_producao SET status = 'concluida' 
             WHERE status = 'cancelada' → BLOQUEADO
```

### Regra 3: Produção Iniciada Sempre Gera Movimentação
```
INVARIANTE: IF status = 'em_andamento' THEN EXISTS baixa_estoque 
            WHERE referencia_producao_id = ordem.id
PROTEÇÃO: Criar registros de baixa atomicamente com mudança de status
VERIFICAÇÃO: SELECT COUNT(*) FROM baixa_estoque 
             WHERE referencia_producao_id = ordem.id > 0
```

### Regra 4: Estorno Só Ocorre para Produções Canceladas
```
INVARIANTE: IF tipo_movimentacao = 'estorno' 
            THEN referencia_producao_id.status = 'cancelada'
PROTEÇÃO: Validar status antes de criar estorno
VERIFICAÇÃO: SELECT * FROM baixa_estoque 
             WHERE tipo_movimentacao = 'estorno' 
             AND referencia_producao_id NOT IN (
               SELECT id FROM ordens_producao WHERE status = 'cancelada'
             )
```

### Regra 5: Dupla Dedução Impossível
```
INVARIANTE: Para cada ordem, estoque deduzido apenas uma vez
PROTEÇÃO: Status 'em_andamento' previne re-entrada
VERIFICAÇÃO: SELECT COUNT(DISTINCT lote_id) FROM baixa_estoque 
             WHERE referencia_producao_id = ordem.id
             DEVE IGUALAR quantidade de lotes consumidos
```

### Regra 6: Quantidade Estornada Iguala Quantidade Deduzida
```
INVARIANTE: SUM(quantidade_baixada WHERE tipo='consumo') = 
            SUM(quantidade_baixada WHERE tipo='estorno')
            (para mesma referencia_producao_id)
PROTEÇÃO: Recuperar exatamente os valores deduzidos
VERIFICAÇÃO: SELECT SUM(quantidade_baixada) FROM baixa_estoque 
             WHERE referencia_producao_id = ordem.id 
             AND tipo_movimentacao = 'consumo'
             DEVE IGUALAR estorno total
```

### Regra 7: Nenhuma Produção Sem Produto Válido
```
INVARIANTE: produto_id SEMPRE referencia um produto_venda existente
PROTEÇÃO: FK constraint em ordens_producao.produto_id
VERIFICAÇÃO: SELECT * FROM ordens_producao 
             WHERE produto_id NOT IN (SELECT id FROM produtos_venda)
             DEVE RETORNAR 0 linhas
```

### Regra 8: Quantidade Produzida Consistente
```
INVARIANTE: quantidade_produzida >= 0
PROTEÇÃO: Validação em schema (z.number().min(0))
VERIFICAÇÃO: SELECT * FROM ordens_producao 
             WHERE quantidade_produzida < 0
             DEVE RETORNAR 0 linhas
```

### Regra 9: Datas Consistentes
```
INVARIANTE: data_inicio <= data_conclusao (quando ambas existem)
            data_cancelamento >= data_inicio (quando cancelada)
PROTEÇÃO: Validação antes de atualizar
VERIFICAÇÃO: SELECT * FROM ordens_producao 
             WHERE data_inicio > data_conclusao
             DEVE RETORNAR 0 linhas
```

### Regra 10: Histórico Imutável
```
INVARIANTE: Registros em baixa_estoque NUNCA são deletados
PROTEÇÃO: Sem DELETE, apenas INSERT
VERIFICAÇÃO: Auditoria completa de todas as movimentações
```

---

## RESUMO EXECUTIVO

### Entidades Principais:
- **ordens_producao**: Controle de produção (status, datas)
- **produtos_venda**: Produto a produzir
- **fichas_tecnicas + ingredientes**: Receitas
- **produto_insumo**: Insumos separados
- **produto_fichas_tecnicas**: Vinculação N:N
- **lotes**: Estoque atual
- **baixa_estoque**: Auditoria de movimentações

### Fluxo de Início:
1. Frontend → `ordensProducao.startProduction` (tRPC)
2. Validar estoque (fichas + insumos separados)
3. Se válido: deduzir estoque (FIFO) + criar registros de baixa
4. Atualizar status para 'em_andamento'

### Proteções Contra Dupla Baixa:
- Status previne re-entrada
- Validação falha se estoque já foi deduzido
- Histórico de movimentações rastreia tudo

### Cancelamento:
- Encontrar todos os consumos da ordem
- Recuperar quantidades exatamente
- Estornar para lotes originais
- Marcar como 'cancelada'
- Impedir finalização posterior

### Invariantes Críticas:
1. Estoque nunca negativo
2. Cancelada não finaliza
3. Iniciada sempre gera movimentação
4. Estorno só para canceladas
5. Dupla dedução impossível
6. Estorno iguala consumo
7. Produto sempre válido
8. Quantidade sempre ≥ 0
9. Datas consistentes
10. Histórico imutável

