import OrdenProducaoList from '@/components/OrdenProducaoList';

export default function OrdenProducaoPage() {
  return <OrdenProducaoList />;
}

