import ProdutosList from "@/components/ProdutosList";

export default function Produtos() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ProdutosList />
    </div>
  );
}

