import InsumosList from "@/components/InsumosList";

export default function Insumos() {
  return (
    <div className="min-h-screen bg-gray-50">
      <InsumosList />
    </div>
  );
}

