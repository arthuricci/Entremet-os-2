import ClientesList from "@/components/ClientesList";

export default function Clientes() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ClientesList />
    </div>
  );
}

