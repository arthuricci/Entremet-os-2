import FichasTecnicasList from '@/components/FichasTecnicasList';

export default function FichasTecnicas() {
  return <FichasTecnicasList />;
}

