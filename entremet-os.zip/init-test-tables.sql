-- Initialize all required tables for production motor testing

-- Insumos (Ingredients/Raw Materials)
CREATE TABLE IF NOT EXISTS insumos (
  id VARCHAR(36) PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  unidade_base VARCHAR(50) NOT NULL,
  nivel_minimo DECIMAL(10, 2) DEFAULT 0,
  tipo_produto VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Produtos (Products)
CREATE TABLE IF NOT EXISTS produtos (
  id VARCHAR(36) PRIMARY KEY,
  nome VARCHAR(255),
  descricao TEXT,
  preco_venda DECIMAL(10, 2),
  ativo BOOLEAN DEFAULT TRUE,
  ficha_tecnica_id VARCHAR(36),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Fichas Técnicas (Technical Sheets)
CREATE TABLE IF NOT EXISTS fichas_tecnicas (
  id VARCHAR(36) PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  modo_de_preparo TEXT,
  rendimento_total DECIMAL(10, 2),
  unidade_rendimento VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Ingredientes (Ingredients in Technical Sheets)
CREATE TABLE IF NOT EXISTS ingredientes (
  id VARCHAR(36) PRIMARY KEY,
  ficha_tecnica_id VARCHAR(36) NOT NULL,
  insumo_id VARCHAR(36) NOT NULL,
  quantidade DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (ficha_tecnica_id) REFERENCES fichas_tecnicas(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

-- Lotes (Stock Batches)
CREATE TABLE IF NOT EXISTS lotes (
  id VARCHAR(36) PRIMARY KEY,
  insumo_id VARCHAR(36) NOT NULL,
  quantidade_atual DECIMAL(10, 2) NOT NULL,
  data_validade DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (insumo_id) REFERENCES insumos(id),
  INDEX idx_insumo_created (insumo_id, created_at)
);

-- Produto Insumo (Product Ingredients)
CREATE TABLE IF NOT EXISTS produto_insumo (
  id VARCHAR(36) PRIMARY KEY,
  produto_id VARCHAR(36) NOT NULL,
  insumo_id VARCHAR(36) NOT NULL,
  quantidade DECIMAL(10, 2) NOT NULL,
  unidade VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (produto_id) REFERENCES produtos(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);

-- Produto Ficha Técnica (Product Technical Sheets)
CREATE TABLE IF NOT EXISTS produto_ficha_tecnica (
  id VARCHAR(36) PRIMARY KEY,
  produto_id VARCHAR(36) NOT NULL,
  ficha_tecnica_id VARCHAR(36) NOT NULL,
  quantidade DECIMAL(10, 2) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (produto_id) REFERENCES produtos(id),
  FOREIGN KEY (ficha_tecnica_id) REFERENCES fichas_tecnicas(id)
);

-- Baixa Estoque (Stock Movements)
CREATE TABLE IF NOT EXISTS baixa_estoque (
  id VARCHAR(36) PRIMARY KEY,
  lote_id VARCHAR(36) NOT NULL,
  quantidade_baixada DECIMAL(10, 2) NOT NULL,
  motivo VARCHAR(255),
  data_baixa TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  referencia_producao_id VARCHAR(36),
  tipo_movimentacao VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (lote_id) REFERENCES lotes(id),
  INDEX idx_referencia_producao (referencia_producao_id)
);

-- Ordens de Produção (Production Orders)
CREATE TABLE IF NOT EXISTS ordens_producao (
  id VARCHAR(36) PRIMARY KEY,
  produto_id VARCHAR(36) NOT NULL,
  quantidade DECIMAL(10, 2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pendente',
  data_inicio TIMESTAMP NULL,
  data_conclusao TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (produto_id) REFERENCES produtos(id),
  INDEX idx_status (status)
);

-- Clientes (Customers)
CREATE TABLE IF NOT EXISTS clientes (
  id VARCHAR(36) PRIMARY KEY,
  nome VARCHAR(255),
  telefone VARCHAR(20),
  instagram VARCHAR(255),
  observacoes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Listas de Compras (Shopping Lists)
CREATE TABLE IF NOT EXISTS listas_compras (
  id VARCHAR(36) PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  descricao TEXT,
  data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Itens Lista de Compras (Shopping List Items)
CREATE TABLE IF NOT EXISTS itens_lista_compras (
  id VARCHAR(36) PRIMARY KEY,
  lista_compras_id VARCHAR(36) NOT NULL,
  insumo_id VARCHAR(36) NOT NULL,
  quantidade DECIMAL(10, 2) NOT NULL,
  unidade VARCHAR(50),
  preco_unitario DECIMAL(10, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (lista_compras_id) REFERENCES listas_compras(id),
  FOREIGN KEY (insumo_id) REFERENCES insumos(id)
);
