-- ============================================================================
-- ARQUITETURA MODULAR: Motor de Produção Atômico em TiDB/MySQL
-- ============================================================================
-- Estratégia: VIEWs + Procedures + SQL Declarativo
-- Atomicidade: Transação única orquestrada pelo backend
-- 
-- Componentes:
--   1. VIEW: v_insumos_consolidados (fichas + separados)
--   2. VIEW: v_estoque_disponivel (lotes por insumo)
--   3. VIEW: v_deficits (insumos com falta)
--   4. PROCEDURE: sp_validate_production_order (validação)
--   5. PROCEDURE: sp_calculate_deficits (cálculo de déficits)
--   6. PROCEDURE: sp_deduct_stock_fifo (dedução FIFO com SQL declarativo)
--   7. PROCEDURE: sp_update_order_status (atualização de status)
--   8. PROCEDURE: sp_start_production_atomic (orquestração)
-- ============================================================================

DELIMITER $$

-- ============================================================================
-- VIEW 1: Consolidar insumos de fichas técnicas + insumos separados
-- ============================================================================
DROP VIEW IF EXISTS v_insumos_consolidados$$

CREATE VIEW v_insumos_consolidados AS
SELECT 
  i.id as insumo_id,
  i.nome as insumo_nome,
  pft.produto_id,
  SUM(ing.quantidade * COALESCE(pft.quantidade, 1)) as quantidade_total
FROM produto_fichas_tecnicas pft
JOIN fichas_tecnicas ft ON pft.ficha_tecnica_id = ft.id
JOIN ingredientes ing ON ft.id = ing.ficha_tecnica_id
JOIN `Insumos` i ON ing.insumo_id = i.id
GROUP BY i.id, i.nome, pft.produto_id

UNION ALL

SELECT 
  i.id as insumo_id,
  i.nome as insumo_nome,
  pi.produto_id,
  pi.quantidade as quantidade_total
FROM produto_insumo pi
JOIN `Insumos` i ON pi.insumo_id = i.id$$

-- ============================================================================
-- VIEW 2: Estoque disponível por insumo
-- ============================================================================
DROP VIEW IF EXISTS v_estoque_disponivel$$

CREATE VIEW v_estoque_disponivel AS
SELECT 
  l.insumo_id,
  COALESCE(SUM(l.quantidade_atual), 0) as quantidade_disponivel
FROM lotes l
GROUP BY l.insumo_id$$

-- ============================================================================
-- VIEW 3: Déficits (insumos com falta)
-- ============================================================================
DROP VIEW IF EXISTS v_deficits$$

CREATE VIEW v_deficits AS
SELECT 
  ic.insumo_id,
  ic.insumo_nome,
  ic.produto_id,
  ic.quantidade_total,
  COALESCE(ed.quantidade_disponivel, 0) as quantidade_disponivel,
  (ic.quantidade_total - COALESCE(ed.quantidade_disponivel, 0)) as deficit
FROM v_insumos_consolidados ic
LEFT JOIN v_estoque_disponivel ed ON ic.insumo_id = ed.insumo_id
WHERE COALESCE(ed.quantidade_disponivel, 0) < ic.quantidade_total$$

-- ============================================================================
-- PROCEDURE 1: Validar se ordem existe e está em status permitido
-- ============================================================================
DROP PROCEDURE IF EXISTS sp_validate_production_order$$

CREATE PROCEDURE sp_validate_production_order(
  IN p_ordem_id CHAR(36),
  OUT p_is_valid INT
)
BEGIN
  SELECT COUNT(*) INTO p_is_valid
  FROM ordens_producao
  WHERE id = p_ordem_id AND status = 'pendente';
END$$

-- ============================================================================
-- PROCEDURE 2: Calcular déficits para um produto
-- ============================================================================
DROP PROCEDURE IF EXISTS sp_calculate_deficits$$

CREATE PROCEDURE sp_calculate_deficits(
  IN p_produto_id CHAR(36),
  IN p_quantidade DECIMAL(10, 2),
  OUT p_has_deficits INT,
  OUT p_deficits_json JSON
)
BEGIN
  SELECT COUNT(*) INTO p_has_deficits
  FROM v_deficits
  WHERE produto_id = p_produto_id
  AND (deficit * p_quantidade) > 0;
  
  IF p_has_deficits > 0 THEN
    SELECT COALESCE(
      JSON_ARRAYAGG(
        JSON_OBJECT(
          'insumo_id', insumo_id,
          'insumo_nome', insumo_nome,
          'necessario', quantidade_total * p_quantidade,
          'disponivel', quantidade_disponivel,
          'deficit', (quantidade_total * p_quantidade) - quantidade_disponivel
        )
      ),
      JSON_ARRAY()
    ) INTO p_deficits_json
    FROM v_deficits
    WHERE produto_id = p_produto_id;
  ELSE
    SET p_deficits_json = JSON_ARRAY();
  END IF;
END$$

-- ============================================================================
-- PROCEDURE 3: Deduzir estoque em FIFO (SQL Declarativo)
-- ============================================================================
DROP PROCEDURE IF EXISTS sp_deduct_stock_fifo$$

CREATE PROCEDURE sp_deduct_stock_fifo(
  IN p_ordem_id CHAR(36),
  IN p_produto_id CHAR(36),
  IN p_quantidade DECIMAL(10, 2),
  OUT p_success INT
)
BEGIN
  -- Handler para capturar erros
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET p_success = 0;
  END;
  
  SET p_success = 1;
  
  -- ========================================================================
  -- PASSO 1: Inserir movimentos de consumo em FIFO
  -- ========================================================================
  -- Para cada insumo consolidado, inserir movimentos de consumo
  -- em FIFO (lotes mais antigos primeiro)
  INSERT INTO baixa_estoque (
    id,
    lote_id,
    quantidade_baixada,
    motivo,
    data_baixa,
    referencia_producao_id,
    tipo_movimentacao,
    created_at,
    updated_at
  )
  SELECT 
    UUID() as id,
    l.id as lote_id,
    GREATEST(
      0,
      LEAST(
        l.quantidade_atual,
        consolidated_qty.quantidade_necessaria - COALESCE(
          (SELECT COALESCE(SUM(l2.quantidade_atual), 0) 
           FROM lotes l2 
           WHERE l2.insumo_id = l.insumo_id 
           AND l2.created_at > l.created_at),
          0
        )
      )
    ) as quantidade_baixada,
    'producao' as motivo,
    NOW() as data_baixa,
    p_ordem_id as referencia_producao_id,
    'consumo_producao' as tipo_movimentacao,
    NOW() as created_at,
    NOW() as updated_at
  FROM (
    -- Consolidar quantidade necessária por insumo
    SELECT 
      ic.insumo_id,
      ic.quantidade_total * p_quantidade as quantidade_necessaria
    FROM v_insumos_consolidados ic
    WHERE ic.produto_id = p_produto_id
  ) consolidated_qty
  JOIN lotes l ON consolidated_qty.insumo_id = l.insumo_id
  ORDER BY l.created_at ASC;
  
  -- Validar se inserção foi bem-sucedida
  IF ROW_COUNT() = 0 THEN
    SET p_success = 0;
  END IF;
  
  -- ========================================================================
  -- PASSO 2: Atualizar quantidade dos lotes
  -- ========================================================================
  -- Deduzir quantidade de cada lote baseado nos movimentos inseridos
  UPDATE lotes l
  JOIN (
    SELECT 
      be.lote_id,
      SUM(be.quantidade_baixada) as total_baixado
    FROM baixa_estoque be
    WHERE be.referencia_producao_id = p_ordem_id
    GROUP BY be.lote_id
  ) be ON l.id = be.lote_id
  SET l.quantidade_atual = l.quantidade_atual - be.total_baixado;
END$$

-- ============================================================================
-- PROCEDURE 4: Atualizar status da ordem
-- ============================================================================
DROP PROCEDURE IF EXISTS sp_update_order_status$$

CREATE PROCEDURE sp_update_order_status(
  IN p_ordem_id CHAR(36),
  IN p_new_status VARCHAR(50),
  OUT p_success INT
)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SET p_success = 0;
  END;
  
  SET p_success = 1;
  
  UPDATE ordens_producao
  SET 
    status = p_new_status,
    data_inicio = CASE WHEN p_new_status = 'em_andamento' THEN NOW() ELSE data_inicio END,
    updated_at = NOW()
  WHERE id = p_ordem_id;
  
  -- Validar se atualização foi bem-sucedida
  IF ROW_COUNT() = 0 THEN
    SET p_success = 0;
  END IF;
END$$

-- ============================================================================
-- PROCEDURE 5: Orquestração Principal (Transação Atômica)
-- ============================================================================
-- NOTA: Esta procedure NÃO executa COMMIT/ROLLBACK
-- O backend deve controlar a transação baseado nos retornos
-- ============================================================================
DROP PROCEDURE IF EXISTS sp_start_production_atomic$$

CREATE PROCEDURE sp_start_production_atomic(
  IN p_ordem_id CHAR(36),
  IN p_produto_id CHAR(36),
  IN p_quantidade DECIMAL(10, 2)
)
BEGIN
  DECLARE v_is_valid INT DEFAULT 0;
  DECLARE v_has_deficits INT DEFAULT 0;
  DECLARE v_deficits_json JSON DEFAULT JSON_ARRAY();
  DECLARE v_deduct_success INT DEFAULT 0;
  DECLARE v_status_success INT DEFAULT 0;
  
  -- Handler para erros SQL
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    SELECT 
      FALSE as success,
      'Erro ao iniciar produção' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'SQL_ERROR' as error_code;
  END;

  -- ========================================================================
  -- PASSO 1: Validar ordem
  -- ========================================================================
  CALL sp_validate_production_order(p_ordem_id, v_is_valid);
  
  IF v_is_valid = 0 THEN
    SELECT 
      FALSE as success,
      'Ordem não encontrada ou status inválido' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'INVALID_ORDER' as error_code;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 2: Verificar déficits
  -- ========================================================================
  CALL sp_calculate_deficits(p_produto_id, p_quantidade, v_has_deficits, v_deficits_json);
  
  IF v_has_deficits > 0 THEN
    SELECT 
      FALSE as success,
      'Estoque insuficiente para os seguintes insumos' as message,
      NULL as ordem_id,
      v_deficits_json as deficits,
      'INSUFFICIENT_STOCK' as error_code;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 3: Deduzir estoque (FIFO)
  -- ========================================================================
  CALL sp_deduct_stock_fifo(p_ordem_id, p_produto_id, p_quantidade, v_deduct_success);
  
  IF v_deduct_success = 0 THEN
    SELECT 
      FALSE as success,
      'Erro ao deduzir estoque' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'DEDUCTION_ERROR' as error_code;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 4: Atualizar status
  -- ========================================================================
  CALL sp_update_order_status(p_ordem_id, 'em_andamento', v_status_success);
  
  IF v_status_success = 0 THEN
    SELECT 
      FALSE as success,
      'Erro ao atualizar status da ordem' as message,
      NULL as ordem_id,
      JSON_ARRAY() as deficits,
      'STATUS_UPDATE_ERROR' as error_code;
    LEAVE sp_start_production_atomic;
  END IF;

  -- ========================================================================
  -- PASSO 5: Retornar sucesso
  -- ========================================================================
  SELECT 
    TRUE as success,
    'Produção iniciada com sucesso' as message,
    p_ordem_id as ordem_id,
    JSON_ARRAY() as deficits,
    'SUCCESS' as error_code;

END$$

DELIMITER ;

-- ============================================================================
-- COMO USAR (com controle de transação no backend):
-- ============================================================================
-- 
-- START TRANSACTION;
-- CALL sp_start_production_atomic(
--   '550e8400-e29b-41d4-a716-446655440000',  -- p_ordem_id
--   '550e8400-e29b-41d4-a716-446655440001',  -- p_produto_id
--   10                                        -- p_quantidade
-- );
-- 
-- -- Backend verifica resultado:
-- -- IF success = TRUE THEN COMMIT;
-- -- ELSE ROLLBACK;
-- -- END IF;
--
-- Resultado (SELECT):
-- - success: TRUE/FALSE
-- - message: Descrição do resultado
-- - ordem_id: UUID da ordem (se sucesso)
-- - deficits: JSON array com lista de déficits ([] se sem déficits)
-- - error_code: SUCCESS | INVALID_ORDER | INSUFFICIENT_STOCK | DEDUCTION_ERROR | STATUS_UPDATE_ERROR | SQL_ERROR

