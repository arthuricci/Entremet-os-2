/**
 * Test Script: Production Motor Validation (Cenários A, B, C, D)
 * 
 * Objetivo: Validar FIFO, atomicidade e rollback com dados determinísticos
 * 
 * Cenários:
 * A: Estoque suficiente (1 insumo, 1 lote) → COMMIT esperado
 * B: Estoque insuficiente → Retorno de déficits + ROLLBACK
 * C: Múltiplos lotes FIFO → Validar consumo por created_at
 * D: Erro forçado no meio → ROLLBACK total
 */

import mysql from 'mysql2/promise';
import { v4 as uuidv4 } from 'uuid';

// ===================================
// CONFIG
// ===================================
// Parse DATABASE_URL
const DATABASE_URL = process.env.DATABASE_URL;
let DB_CONFIG = {};

if (DATABASE_URL) {
  // Parse mysql://user:password@host:port/database?ssl=...
  const url = new URL(DATABASE_URL);
  DB_CONFIG = {
    host: url.hostname,
    port: parseInt(url.port) || 3306,
    user: url.username,
    password: url.password,
    database: url.pathname.split('/')[1],
    ssl: {
      rejectUnauthorized: false,  // For TiDB Cloud
    },
    waitForConnections: true,
    connectionLimit: 1,
    queueLimit: 0,
  };
} else {
  DB_CONFIG = {
    host: process.env.DB_HOST || 'localhost',
    port: 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'entremet_os',
  };
}

console.log('[CONFIG] Conectando a:', DB_CONFIG.host);

const API_URL = 'http://localhost:3000/api/trpc/producao.startProduction';

// UUIDs Determinísticos
const TEST_IDS = {
  produto_a: '11111111-1111-1111-1111-111111111111',
  produto_b: '22222222-2222-2222-2222-222222222222',
  produto_c: '33333333-3333-3333-3333-333333333333',
  insumo_a: 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  insumo_b: 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
  ordem_a: 'cccccccc-cccc-cccc-cccc-cccccccccccc',
  ordem_b: 'dddddddd-dddd-dddd-dddd-dddddddddddd',
  ordem_c: 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee',
  ordem_d: 'ffffffff-ffff-ffff-ffff-ffffffffffff',
};

// ===================================
// HELPER FUNCTIONS
// ===================================
async function getDbConnection() {
  try {
    const conn = await mysql.createConnection(DB_CONFIG);
    console.log('[DB] Conexão estabelecida');
    return conn;
  } catch (error) {
    console.error('[DB] Erro na conexão:', error.message);
    throw error;
  }
}

async function cleanupTestData(conn) {
  console.log('\n[CLEANUP] Removendo dados de teste anteriores...');
  try {
    // Deletar em ordem de dependência
    await conn.execute('DELETE FROM baixa_estoque WHERE referencia_producao_id IN (?, ?, ?, ?)', 
      [TEST_IDS.ordem_a, TEST_IDS.ordem_b, TEST_IDS.ordem_c, TEST_IDS.ordem_d]);
    
    await conn.execute('DELETE FROM ordens_producao WHERE id IN (?, ?, ?, ?)', 
      [TEST_IDS.ordem_a, TEST_IDS.ordem_b, TEST_IDS.ordem_c, TEST_IDS.ordem_d]);
    
    await conn.execute('DELETE FROM lotes WHERE insumo_id IN (?, ?)', 
      [TEST_IDS.insumo_a, TEST_IDS.insumo_b]);
    
    await conn.execute('DELETE FROM produto_insumo WHERE produto_id IN (?, ?, ?) OR insumo_id IN (?, ?)', 
      [TEST_IDS.produto_a, TEST_IDS.produto_b, TEST_IDS.produto_c, TEST_IDS.insumo_a, TEST_IDS.insumo_b]);
    
    await conn.execute('DELETE FROM produtos WHERE id IN (?, ?, ?)', 
      [TEST_IDS.produto_a, TEST_IDS.produto_b, TEST_IDS.produto_c]);
    
    await conn.execute('DELETE FROM insumos WHERE id IN (?, ?)', 
      [TEST_IDS.insumo_a, TEST_IDS.insumo_b]);
    
    console.log('[CLEANUP] ✅ Dados de teste removidos');
  } catch (error) {
    console.log('[CLEANUP] ⚠️ Erro ao limpar (pode ser normal se não existem dados):', error.message);
  }
}

async function setupTestData(conn) {
  console.log('\n[SETUP] Criando dados de teste determinísticos...');
  
  // Criar insumos
  await conn.execute(
    'INSERT INTO insumos (id, nome, unidade_base, nivel_minimo, tipo_produto, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.insumo_a, 'Insumo Teste A', 'kg', 0, 'ingrediente']
  );
  
  await conn.execute(
    'INSERT INTO insumos (id, nome, unidade_base, nivel_minimo, tipo_produto, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.insumo_b, 'Insumo Teste B', 'L', 0, 'ingrediente']
  );
  
  // Criar produtos
  await conn.execute(
    'INSERT INTO produtos (id, nome, descricao, preco_venda, ativo, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.produto_a, 'Produto Teste A', 'Para cenário A', 100, true]
  );
  
  await conn.execute(
    'INSERT INTO produtos (id, nome, descricao, preco_venda, ativo, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.produto_b, 'Produto Teste B', 'Para cenário B', 100, true]
  );
  
  await conn.execute(
    'INSERT INTO produtos (id, nome, descricao, preco_venda, ativo, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.produto_c, 'Produto Teste C', 'Para cenário C (FIFO)', 100, true]
  );
  
  // Associar insumos aos produtos
  await conn.execute(
    'INSERT INTO produto_insumo (id, produto_id, insumo_id, quantidade, unidade, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [uuidv4(), TEST_IDS.produto_a, TEST_IDS.insumo_a, 10, 'kg']
  );
  
  await conn.execute(
    'INSERT INTO produto_insumo (id, produto_id, insumo_id, quantidade, unidade, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [uuidv4(), TEST_IDS.produto_b, TEST_IDS.insumo_a, 100, 'kg']
  );
  
  await conn.execute(
    'INSERT INTO produto_insumo (id, produto_id, insumo_id, quantidade, unidade, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())',
    [uuidv4(), TEST_IDS.produto_c, TEST_IDS.insumo_b, 5, 'L']
  );
  
  console.log('[SETUP] ✅ Produtos e insumos criados');
}

async function setupCenarioA(conn) {
  console.log('\n[CENÁRIO A] Setup: Estoque suficiente (1 insumo, 1 lote, 100kg)');
  
  // Lote com 100kg (necessário: 10kg × 1 = 10kg)
  const loteId = uuidv4();
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), NOW(), NOW())',
    [loteId, TEST_IDS.insumo_a, 100.00]
  );
  
  // Ordem com status 'pendente'
  await conn.execute(
    'INSERT INTO ordens_producao (id, produto_id, quantidade_produzida, status, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.ordem_a, TEST_IDS.produto_a, 1.00, 'pendente']
  );
  
  console.log('[CENÁRIO A] ✅ Setup concluído');
  return { loteId };
}

async function setupCenarioB(conn) {
  console.log('\n[CENÁRIO B] Setup: Estoque insuficiente (necessário 100kg, disponível 50kg)');
  
  // Lote com 50kg (necessário: 100kg × 1 = 100kg)
  const loteId = uuidv4();
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), NOW(), NOW())',
    [loteId, TEST_IDS.insumo_a, 50.00]
  );
  
  // Ordem com status 'pendente'
  await conn.execute(
    'INSERT INTO ordens_producao (id, produto_id, quantidade_produzida, status, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.ordem_b, TEST_IDS.produto_b, 1.00, 'pendente']
  );
  
  console.log('[CENÁRIO B] ✅ Setup concluído');
  return { loteId };
}

async function setupCenarioC(conn) {
  console.log('\n[CENÁRIO C] Setup: Múltiplos lotes FIFO (3 lotes, consumir 2 primeiros)');
  
  // 3 lotes com created_at diferentes
  const lote1 = uuidv4();
  const lote2 = uuidv4();
  const lote3 = uuidv4();
  
  // Lote 1: 3L (criado há 3 dias)
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 3 DAY), NOW())',
    [lote1, TEST_IDS.insumo_b, 3.00]
  );
  
  // Lote 2: 3L (criado há 2 dias)
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY), NOW())',
    [lote2, TEST_IDS.insumo_b, 3.00]
  );
  
  // Lote 3: 3L (criado há 1 dia)
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY), NOW())',
    [lote3, TEST_IDS.insumo_b, 3.00]
  );
  
  // Ordem: quantidade 2 (necessário: 5L × 2 = 10L)
  // Esperado: consumir Lote1 (3L) + Lote2 (3L) + Lote3 (4L)
  await conn.execute(
    'INSERT INTO ordens_producao (id, produto_id, quantidade_produzida, status, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.ordem_c, TEST_IDS.produto_c, 2.00, 'pendente']
  );
  
  console.log('[CENÁRIO C] ✅ Setup concluído (3 lotes: 3L + 3L + 3L)');
  return { lote1, lote2, lote3 };
}

async function setupCenarioD(conn) {
  console.log('\n[CENÁRIO D] Setup: Erro forçado (estoque suficiente, mas erro no meio)');
  
  // Lote com 100kg
  const loteId = uuidv4();
  await conn.execute(
    'INSERT INTO lotes (id, insumo_id, quantidade_atual, data_validade, created_at, updated_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), NOW(), NOW())',
    [loteId, TEST_IDS.insumo_a, 100.00]
  );
  
  // Ordem com status 'pendente'
  await conn.execute(
    'INSERT INTO ordens_producao (id, produto_id, quantidade_produzida, status, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())',
    [TEST_IDS.ordem_d, TEST_IDS.produto_a, 1.00, 'pendente']
  );
  
  console.log('[CENÁRIO D] ✅ Setup concluído');
  return { loteId };
}

async function callTRPC(ordemId, produtoId, quantidade) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        json: { ordemId, produtoId, quantidade }
      })
    });
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('[TRPC] Erro na chamada:', error.message);
    throw error;
  }
}

async function getStockStatus(conn, insumoId) {
  const [rows] = await conn.execute(
    'SELECT SUM(quantidade_atual) as total FROM lotes WHERE insumo_id = ?',
    [insumoId]
  );
  return rows[0]?.total || 0;
}

async function getLotesStatus(conn, insumoId) {
  const [rows] = await conn.execute(
    'SELECT id, quantidade_atual, created_at FROM lotes WHERE insumo_id = ? ORDER BY created_at ASC',
    [insumoId]
  );
  return rows;
}

async function getOrderStatus(conn, ordemId) {
  const [rows] = await conn.execute(
    'SELECT status, data_inicio FROM ordens_producao WHERE id = ?',
    [ordemId]
  );
  return rows[0] || null;
}

async function getBaixasEstoque(conn, ordemId) {
  const [rows] = await conn.execute(
    'SELECT lote_id, quantidade_baixada, tipo_movimentacao FROM baixa_estoque WHERE referencia_producao_id = ? ORDER BY created_at ASC',
    [ordemId]
  );
  return rows;
}

// ===================================
// MAIN TEST EXECUTION
// ===================================
async function main() {
  let conn;
  
  try {
    conn = await getDbConnection();
    console.log('✅ Conectado ao banco de dados');
    
    // Cleanup
    await cleanupTestData(conn);
    
    // Setup geral
    await setupTestData(conn);
    
    // ===================================
    // CENÁRIO A: Estoque Suficiente
    // ===================================
    console.log('\n' + '='.repeat(80));
    console.log('CENÁRIO A: Estoque Suficiente (1 insumo, 1 lote)');
    console.log('='.repeat(80));
    
    const cenarioA = await setupCenarioA(conn);
    const stockABefore = await getStockStatus(conn, TEST_IDS.insumo_a);
    console.log(`[PRÉ] Estoque Insumo A: ${stockABefore}kg`);
    
    const resultA = await callTRPC(TEST_IDS.ordem_a, TEST_IDS.produto_a, 1);
    console.log('[RESULTADO]', JSON.stringify(resultA, null, 2));
    
    const stockAAfter = await getStockStatus(conn, TEST_IDS.insumo_a);
    const orderAStatus = await getOrderStatus(conn, TEST_IDS.ordem_a);
    const baixasA = await getBaixasEstoque(conn, TEST_IDS.ordem_a);
    
    console.log(`[PÓS] Estoque Insumo A: ${stockAAfter}kg`);
    console.log(`[PÓS] Status Ordem A: ${orderAStatus?.status}`);
    console.log(`[PÓS] Baixas Estoque:`, baixasA);
    
    console.log('\n[VALIDAÇÃO A]');
    console.log(`  ✓ Estoque deduzido: ${stockABefore - stockAAfter === 10 ? 'SIM (10kg)' : 'NÃO'}`);
    console.log(`  ✓ Status = 'em_andamento': ${orderAStatus?.status === 'em_andamento' ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Registros em baixa_estoque: ${baixasA.length}`);
    
    // ===================================
    // CENÁRIO B: Estoque Insuficiente
    // ===================================
    console.log('\n' + '='.repeat(80));
    console.log('CENÁRIO B: Estoque Insuficiente');
    console.log('='.repeat(80));
    
    const cenarioB = await setupCenarioB(conn);
    const stockBBefore = await getStockStatus(conn, TEST_IDS.insumo_a);
    console.log(`[PRÉ] Estoque Insumo A: ${stockBBefore}kg`);
    
    const resultB = await callTRPC(TEST_IDS.ordem_b, TEST_IDS.produto_b, 1);
    console.log('[RESULTADO]', JSON.stringify(resultB, null, 2));
    
    const stockBAfter = await getStockStatus(conn, TEST_IDS.insumo_a);
    const orderBStatus = await getOrderStatus(conn, TEST_IDS.ordem_b);
    const baixasB = await getBaixasEstoque(conn, TEST_IDS.ordem_b);
    
    console.log(`[PÓS] Estoque Insumo A: ${stockBAfter}kg`);
    console.log(`[PÓS] Status Ordem B: ${orderBStatus?.status}`);
    console.log(`[PÓS] Baixas Estoque: ${baixasB.length}`);
    
    console.log('\n[VALIDAÇÃO B]');
    console.log(`  ✓ Estoque intacto (ROLLBACK): ${stockBBefore === stockBAfter ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Déficits retornados: ${resultB.error?.json?.data?.deficits ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Status = 'pendente': ${orderBStatus?.status === 'pendente' ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Nenhuma baixa registrada: ${baixasB.length === 0 ? 'SIM' : 'NÃO'}`);
    
    // ===================================
    // CENÁRIO C: FIFO com Múltiplos Lotes
    // ===================================
    console.log('\n' + '='.repeat(80));
    console.log('CENÁRIO C: FIFO com Múltiplos Lotes');
    console.log('='.repeat(80));
    
    const cenarioC = await setupCenarioC(conn);
    const lotesC = await getLotesStatus(conn, TEST_IDS.insumo_b);
    console.log('[PRÉ] Lotes (ordem created_at):');
    lotesC.forEach((lote, idx) => {
      console.log(`  Lote ${idx + 1}: ${lote.quantidade_atual}L (criado: ${lote.created_at})`);
    });
    
    const resultC = await callTRPC(TEST_IDS.ordem_c, TEST_IDS.produto_c, 2);
    console.log('[RESULTADO]', JSON.stringify(resultC, null, 2));
    
    const lotesCAfter = await getLotesStatus(conn, TEST_IDS.insumo_b);
    const orderCStatus = await getOrderStatus(conn, TEST_IDS.ordem_c);
    const baixasC = await getBaixasEstoque(conn, TEST_IDS.ordem_c);
    
    console.log('[PÓS] Lotes após dedução:');
    lotesCAfter.forEach((lote, idx) => {
      console.log(`  Lote ${idx + 1}: ${lote.quantidade_atual}L`);
    });
    console.log(`[PÓS] Registros em baixa_estoque: ${baixasC.length}`);
    console.log('[PÓS] Detalhes de baixa:');
    baixasC.forEach((baixa, idx) => {
      console.log(`  ${idx + 1}. Lote ${baixa.lote_id.substring(0, 8)}: ${baixa.quantidade_baixada}L`);
    });
    
    console.log('\n[VALIDAÇÃO C]');
    console.log(`  ✓ FIFO respeitado (Lote1 > Lote2 > Lote3): ${baixasC.length === 3 ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Total deduzido: 10L: ${baixasC.reduce((sum, b) => sum + b.quantidade_baixada, 0) === 10 ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Status = 'em_andamento': ${orderCStatus?.status === 'em_andamento' ? 'SIM' : 'NÃO'}`);
    
    // ===================================
    // CENÁRIO D: Erro Forçado (Rollback Total)
    // ===================================
    console.log('\n' + '='.repeat(80));
    console.log('CENÁRIO D: Erro Forçado (Simular Rollback)');
    console.log('='.repeat(80));
    
    const cenarioD = await setupCenarioD(conn);
    const stockDBefore = await getStockStatus(conn, TEST_IDS.insumo_a);
    console.log(`[PRÉ] Estoque Insumo A: ${stockDBefore}kg`);
    
    // Simular erro: deletar a ordem antes da chamada para forçar erro na validação
    await conn.execute('DELETE FROM ordens_producao WHERE id = ?', [TEST_IDS.ordem_d]);
    
    const resultD = await callTRPC(TEST_IDS.ordem_d, TEST_IDS.produto_a, 1);
    console.log('[RESULTADO]', JSON.stringify(resultD, null, 2));
    
    const stockDAfter = await getStockStatus(conn, TEST_IDS.insumo_a);
    const baixasD = await getBaixasEstoque(conn, TEST_IDS.ordem_d);
    
    console.log(`[PÓS] Estoque Insumo A: ${stockDAfter}kg`);
    console.log(`[PÓS] Baixas Estoque: ${baixasD.length}`);
    
    console.log('\n[VALIDAÇÃO D]');
    console.log(`  ✓ Estoque intacto (ROLLBACK): ${stockDBefore === stockDAfter ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Erro retornado: ${resultD.error ? 'SIM' : 'NÃO'}`);
    console.log(`  ✓ Nenhuma baixa registrada: ${baixasD.length === 0 ? 'SIM' : 'NÃO'}`);
    
    // ===================================
    // RESUMO FINAL
    // ===================================
    console.log('\n' + '='.repeat(80));
    console.log('RESUMO FINAL');
    console.log('='.repeat(80));
    console.log('✅ Todos os cenários executados');
    console.log('📋 Verifique os logs acima para validar cada cenário');
    
  } catch (error) {
    console.error('❌ Erro:', error.message);
    console.error('Stack:', error.stack);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

main();
